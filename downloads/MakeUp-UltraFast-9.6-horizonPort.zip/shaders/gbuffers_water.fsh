#version 120
#extension GL_ARB_shader_texture_lod : enable
// horizon-shaderport noise-2d: the game loads no noise texture; built from the pack's image
#ifndef HZ_TEX2N
#define HZ_TEX2N
// noisetex is a bvec3: no other stand-in overloads that type (naga takes two struct types as one)
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// textures/water_256_RG_8bit.png 256x256: r smooth (26 cells), g smooth (13 cells), b flat, a flat
float hz_n2_q0(float x) {
    if (x <= 0.170844) return mix(0.337255, 0.439216, clamp((x - 0.001875) / 0.168969, 0.0, 1.0));
    if (x <= 0.238397) return mix(0.439216, 0.454902, clamp((x - 0.170844) / 0.067553, 0.0, 1.0));
    if (x <= 0.295374) return mix(0.454902, 0.466667, clamp((x - 0.238397) / 0.056977, 0.0, 1.0));
    if (x <= 0.341684) return mix(0.466667, 0.474510, clamp((x - 0.295374) / 0.046310, 0.0, 1.0));
    if (x <= 0.385921) return mix(0.474510, 0.482353, clamp((x - 0.341684) / 0.044237, 0.0, 1.0));
    if (x <= 0.423387) return mix(0.482353, 0.486275, clamp((x - 0.385921) / 0.037466, 0.0, 1.0));
    if (x <= 0.462605) return mix(0.486275, 0.494118, clamp((x - 0.423387) / 0.039217, 0.0, 1.0));
    if (x <= 0.501723) return mix(0.494118, 0.501961, clamp((x - 0.462605) / 0.039118, 0.0, 1.0));
    if (x <= 0.539509) return mix(0.501961, 0.505882, clamp((x - 0.501723) / 0.037786, 0.0, 1.0));
    if (x <= 0.578844) return mix(0.505882, 0.513726, clamp((x - 0.539509) / 0.039335, 0.0, 1.0));
    if (x <= 0.620533) return mix(0.513726, 0.517647, clamp((x - 0.578844) / 0.041689, 0.0, 1.0));
    if (x <= 0.664440) return mix(0.517647, 0.525490, clamp((x - 0.620533) / 0.043907, 0.0, 1.0));
    if (x <= 0.712299) return mix(0.525490, 0.533333, clamp((x - 0.664440) / 0.047859, 0.0, 1.0));
    if (x <= 0.764425) return mix(0.533333, 0.545098, clamp((x - 0.712299) / 0.052126, 0.0, 1.0));
    if (x <= 0.833869) return mix(0.545098, 0.564706, clamp((x - 0.764425) / 0.069444, 0.0, 1.0));
    if (x <= 0.997528) return mix(0.564706, 0.678431, clamp((x - 0.833869) / 0.163659, 0.0, 1.0));
    return 0.678431;
}
float hz_n2_q1(float x) {
    if (x <= 0.140049) return mix(0.305882, 0.427451, clamp((x - 0.003115) / 0.136935, 0.0, 1.0));
    if (x <= 0.197311) return mix(0.427451, 0.447059, clamp((x - 0.140049) / 0.057262, 0.0, 1.0));
    if (x <= 0.257483) return mix(0.447059, 0.458824, clamp((x - 0.197311) / 0.060172, 0.0, 1.0));
    if (x <= 0.313091) return mix(0.458824, 0.470588, clamp((x - 0.257483) / 0.055608, 0.0, 1.0));
    if (x <= 0.357752) return mix(0.470588, 0.478431, clamp((x - 0.313091) / 0.044661, 0.0, 1.0));
    if (x <= 0.405487) return mix(0.478431, 0.486275, clamp((x - 0.357752) / 0.047734, 0.0, 1.0));
    if (x <= 0.449243) return mix(0.486275, 0.494118, clamp((x - 0.405487) / 0.043756, 0.0, 1.0));
    if (x <= 0.492976) return mix(0.494118, 0.501961, clamp((x - 0.449243) / 0.043733, 0.0, 1.0));
    if (x <= 0.530906) return mix(0.501961, 0.505882, clamp((x - 0.492976) / 0.037930, 0.0, 1.0));
    if (x <= 0.568674) return mix(0.505882, 0.513726, clamp((x - 0.530906) / 0.037768, 0.0, 1.0));
    if (x <= 0.607197) return mix(0.513726, 0.521569, clamp((x - 0.568674) / 0.038523, 0.0, 1.0));
    if (x <= 0.645885) return mix(0.521569, 0.529412, clamp((x - 0.607197) / 0.038688, 0.0, 1.0));
    if (x <= 0.689749) return mix(0.529412, 0.541176, clamp((x - 0.645885) / 0.043864, 0.0, 1.0));
    if (x <= 0.743269) return mix(0.541176, 0.552941, clamp((x - 0.689749) / 0.053520, 0.0, 1.0));
    if (x <= 0.816194) return mix(0.552941, 0.572549, clamp((x - 0.743269) / 0.072924, 0.0, 1.0));
    if (x <= 0.993385) return mix(0.572549, 0.709804, clamp((x - 0.816194) / 0.177191, 0.0, 1.0));
    return 0.709804;
}
vec4 hz_n2_img(vec2 p) { return vec4(hz_n2_q0(hz_t3_noise(vec3(p, 0.0), 26.000000, 17.000000)), hz_n2_q1(hz_t3_noise(vec3(p, 0.0), 13.000000, 70.000000)), 0.000000, 1.000000); }
const ivec2 hz_n2_size = ivec2(256, 256);
#ifndef texture
vec4 texture(bvec3 t, vec2 p) { return hz_n2_img(p); }
vec4 texture(bvec3 t, vec2 p, float bias) { return hz_n2_img(p); }
#endif
vec4 textureLod(bvec3 t, vec2 p, float lod) { return hz_n2_img(p); }
vec4 textureGrad(bvec3 t, vec2 p, vec2 dx, vec2 dy) { return hz_n2_img(p); }
vec4 texelFetch(bvec3 t, ivec2 c, int lod) { return hz_n2_img((vec2(c) + 0.5) / vec2(hz_n2_size)); }
ivec2 textureSize(bvec3 t, int lod) { return max(hz_n2_size >> lod, ivec2(1)); }
#endif
#define main hz_pack_main
#define HZ_NFIX_binormal
#define HZ_NFIX_tangent
in float hz_FogFragCoord;
/* MakeUp - gbuffers_water.fsh
Render: Water and translucent blocks

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define USE_BASIC_SH // Sets the use of a "basic" or "generic" shader for custom dimensions, instead of the default overworld shader. This can solve some rendering issues as the shader is closer to vanilla rendering.

#ifdef USE_BASIC_SH
    #define UNKNOWN_DIM
#endif
#define GBUFFER_WATER
#define WATER_F

#include "/common/water_blocks_fragment.glsl"

// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    binormal = hz_nfix_rv * hz_nfix_in_binormal;
    tangent = hz_nfix_rv * hz_nfix_in_tangent;
    hz_pack_main();
}
