#version 120
#extension GL_ARB_shader_texture_lod : enable
#define main hz_pack_main
#define HZ_NFIX_binormal
#define HZ_NFIX_tangent
out float hz_FogFragCoord;
/* MakeUp - gbuffers_water.vsh
Render: Water and translucent blocks

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define WATER_F
#define NO_SHADOWS

#include "/common/water_blocks_vertex.glsl"


// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_binormal = binormal;
    hz_nfix_in_tangent = tangent;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
