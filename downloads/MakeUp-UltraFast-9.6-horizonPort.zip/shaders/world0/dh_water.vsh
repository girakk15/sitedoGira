#version 120
#extension GL_ARB_shader_texture_lod : enable
float hz_FogFragCoord;
/* MakeUp - dh_water.vsh
Render: DH Water

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define DH_WATER

#include "/common/solid_dh_water_vertex.glsl"
