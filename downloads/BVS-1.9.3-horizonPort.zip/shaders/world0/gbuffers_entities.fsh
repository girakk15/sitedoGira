#version 130
// horizon-shaderport pbr-defaults: no PBR atlases in Horizon; the values Iris gives without them
#ifndef HZ_CTEX
#define HZ_CTEX
struct hz_ctex { vec4 v; };
#ifndef texture
vec4 texture(hz_ctex t, vec2 p) { return t.v; }
vec4 texture(hz_ctex t, vec2 p, float bias) { return t.v; }
#endif
vec4 textureLod(hz_ctex t, vec2 p, float lod) { return t.v; }
vec4 textureGrad(hz_ctex t, vec2 p, vec2 dx, vec2 dy) { return t.v; }
vec4 texelFetch(hz_ctex t, ivec2 p, int lod) { return t.v; }
ivec2 textureSize(hz_ctex t, int lod) { return ivec2(1); }
#endif

#include "/settings.glsl"

in vec2 TexCoords;
in vec2 LightmapCoords;
in vec4 Color;
#ifdef HZ_NFIX_tangent
in vec3 hz_nfix_in_tangent; vec3 tangent;
#else
in vec3 tangent;
#endif
#ifdef HZ_NFIX_viewSpaceGeoNormal
in vec3 hz_nfix_in_viewSpaceGeoNormal; vec3 viewSpaceGeoNormal;
#else
in vec3 viewSpaceGeoNormal;
#endif
#ifdef HZ_NFIX_Normal
in vec3 hz_nfix_in_Normal; vec3 Normal;
#else
in vec3 Normal;
#endif
uniform int entityId;

uniform sampler2D texture;
const hz_ctex normals = hz_ctex(vec4(0.5, 0.5, 1.0, 1.0));
uniform vec4 entityColor;
uniform vec3 shadowLightPosition;

uniform mat4 gbufferModelViewInverse;

mat3 tbnNormalTangent(vec3 normal, vec3 tangent) {
    vec3 bitangent = normalize(cross(tangent,normal));
    return mat3(tangent, bitangent, normal);
}

void main(){
    vec4 albedo = texture2D(texture, TexCoords) * Color;
	albedo.rgb = mix(albedo.rgb, entityColor.rgb, entityColor.a);
	
	vec3 shadowLightDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
	float diffuseLight = 0.0f;
	
	#if PBR == 1
	vec3 viewSpaceInitialTangent = tangent.xyz;
	vec3 viewSpaceTangent = normalize(viewSpaceInitialTangent - dot(viewSpaceInitialTangent, viewSpaceGeoNormal) * viewSpaceGeoNormal);
	
	vec2 normalData = vec2(texture(normals,TexCoords)).xy * 2.0 - 1.0;
	vec3 normalNormalSpace = vec3(normalData.xy,sqrt(1.0 - dot(normalData.xy, normalData.xy)));
	mat3 TBN = tbnNormalTangent(viewSpaceGeoNormal, viewSpaceTangent);
	vec3 normalViewSpace = TBN * normalNormalSpace;
	vec3 normalWorldSpace = mat3(gbufferModelViewInverse) * normalViewSpace;

	diffuseLight = clamp(dot(shadowLightDir, normalWorldSpace), 0.0f, 1.0f);
	#else
	diffuseLight = clamp(dot(shadowLightDir, Normal), 0.0f, 1.0f);
	#endif
	
	if (int(entityId) == 1) {
		diffuseLight = 1;
	}
	
/* DRAWBUFFERS:0234 */
gl_FragData[0] = albedo;
gl_FragData[1] = vec4(LightmapCoords, diffuseLight, 1.0f);
gl_FragData[2] = vec4(1.0f, 0.0f, 0.0f, 1.0f); // Пишем маску сущностей в colortex3
gl_FragData[3] = vec4(viewSpaceGeoNormal * 0.5 + 0.5, 1.0f);
}
