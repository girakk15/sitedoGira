#version 130
in float hz_FogFragCoord;

in vec2 TexCoords;
in vec4 Color;
#ifdef HZ_NFIX_Normal
in vec3 hz_nfix_in_Normal; vec3 Normal;
#else
in vec3 Normal;
#endif
uniform vec3 skyColor;

uniform float near, far;
uniform sampler2D texture;

void main(){
    vec4 albedo = texture2D(texture, TexCoords) * Color;
	albedo.a *= 0.6;
	
	float fog;
    fog = clamp((hz_FogFragCoord - far) * (near * 0.1), 0.0f, 1.0f);
	if(gl_Fog.color.rgb != vec3(0.0f))
	{
		albedo.a = mix(albedo.a, 0, fog);
	}
	
    /* DRAWBUFFERS:0 */
    gl_FragData[0] = albedo;
}
