#version 130
// horizon-shaderport pbr-defaults: no PBR atlases in Horizon; the values Iris gives without them
#ifndef HZ_CTEX
#define HZ_CTEX
struct hz_ctex { vec4 v; };
#ifndef texture
vec4 texture(hz_ctex t, vec2 p) { return t.v; }
vec4 texture(hz_ctex t, vec2 p, float bias) { return t.v; }
#endif
vec4 textureLod(hz_ctex t, vec2 p, float lod) { return t.v; }
vec4 textureGrad(hz_ctex t, vec2 p, vec2 dx, vec2 dy) { return t.v; }
vec4 texelFetch(hz_ctex t, ivec2 p, int lod) { return t.v; }
ivec2 textureSize(hz_ctex t, int lod) { return ivec2(1); }
#endif
#define main hz_pack_main
#define HZ_NFIX_tangent
#define HZ_NFIX_viewSpaceGeoNormal

#include "/settings.glsl"

in vec2 TexCoords;
in vec2 LightmapCoords;
in vec3 foliageColor;
#ifdef HZ_NFIX_tangent
in vec3 hz_nfix_in_tangent; vec3 tangent;
#else
in vec3 tangent;
#endif
#ifdef HZ_NFIX_viewSpaceGeoNormal
in vec3 hz_nfix_in_viewSpaceGeoNormal; vec3 viewSpaceGeoNormal;
#else
in vec3 viewSpaceGeoNormal;
#endif
in float blockId;

uniform sampler2D gtexture;
const hz_ctex normals = hz_ctex(vec4(0.5, 0.5, 1.0, 1.0));
const hz_ctex specular = hz_ctex(vec4(0.0));
uniform sampler2D noisetex;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;
uniform float frameTimeCounter;

uniform mat4 gbufferModelViewInverse;

vec2 encode (vec3 n){
    return vec2(n.xy * inversesqrt(n.z * 8.0 + 8.0) + 0.5);
}

void main(){
    vec4 outputColorData = texture2D(gtexture, TexCoords);
	vec3 albedo = outputColorData.rgb * foliageColor;
	vec3 norm = viewSpaceGeoNormal;
	float diffuseLight = 0.25;
	vec2 normalssr = vec2(0.001f);
	vec3 shadowLightDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
	
	if (int(blockId + 0.5) == 1000) {
		outputColorData.a = 0.87f;
        diffuseLight = clamp(dot(shadowLightDir, viewSpaceGeoNormal), 0.0f, 1.0f);
		
		#if SSR == 1
		vec4 noiseSample = texture2D(noisetex, (TexCoords + frameTimeCounter * 0.0005) * 16); // 512
		vec3 noiseEffect = noiseSample.rgb * 0.025;
		norm += noiseEffect;
		norm = normalize(norm);
		normalssr = encode(norm);
		#else
		normalssr.x = 1.0f;
		#endif
    }
	
    /* DRAWBUFFERS:0234 */
    gl_FragData[0] = vec4(albedo, outputColorData.a);
    gl_FragData[1] = vec4(LightmapCoords, diffuseLight, outputColorData.a);
	gl_FragData[2] = vec4(normalssr, vec2(1.0f));
	gl_FragData[3] = vec4(viewSpaceGeoNormal * 0.5 + 0.5, 1.0f);
}

// face-normals (horizon-shaderport)
#undef main
in vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    tangent = hz_nfix_rv * hz_nfix_in_tangent;
    viewSpaceGeoNormal = hz_nfix_rv * hz_nfix_in_viewSpaceGeoNormal;
    hz_pack_main();
}
