#if MC_VERSION >= 1800
	#version 120
in float hz_FogFragCoord;
	#include "/program/gbuffers_clouds.fsh"
#endif