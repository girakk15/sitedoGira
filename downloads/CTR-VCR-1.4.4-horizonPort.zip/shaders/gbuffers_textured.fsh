#version 120
in float hz_FogFragCoord;
#include "/program/gbuffers_textured.fsh"