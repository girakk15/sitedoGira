out float hz_FogFragCoord;
#define HAND
#include "/gbuffers_textured.vsh"