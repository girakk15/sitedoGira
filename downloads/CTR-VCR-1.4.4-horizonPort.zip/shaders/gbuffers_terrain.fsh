in float hz_FogFragCoord;
#define TERRAIN
#include "gbuffers_textured.fsh"