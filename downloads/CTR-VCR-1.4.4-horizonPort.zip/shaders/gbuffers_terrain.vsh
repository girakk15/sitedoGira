out float hz_FogFragCoord;
#define TERRAIN
#include "gbuffers_textured.vsh"