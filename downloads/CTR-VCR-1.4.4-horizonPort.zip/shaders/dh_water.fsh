in float hz_FogFragCoord;
#define DH
#define DH_WATER
#include "gbuffers_terrain.fsh"