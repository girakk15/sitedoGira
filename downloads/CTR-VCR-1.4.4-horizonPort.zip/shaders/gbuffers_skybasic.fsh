in float hz_FogFragCoord;
#define SKYBASIC
#include "gbuffers_basic.fsh"