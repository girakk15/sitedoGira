in float hz_FogFragCoord;
#define DH
#define DH_TERRAIN
#include "gbuffers_terrain.fsh"