out float hz_FogFragCoord;
#define WEATHER
#include "/gbuffers_textured.vsh"