#if MC_VERSION >= 1800
	#version 120
out float hz_FogFragCoord;
	#include "/program/gbuffers_clouds.vsh"
#endif