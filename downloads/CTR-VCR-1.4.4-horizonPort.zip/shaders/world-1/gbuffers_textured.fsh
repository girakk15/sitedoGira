#version 120
in float hz_FogFragCoord;
#define THE_NETHER
#include "/program/gbuffers_textured.fsh"