#version 120
out float hz_FogFragCoord;
#define THE_NETHER
#include "/program/gbuffers_textured.vsh"