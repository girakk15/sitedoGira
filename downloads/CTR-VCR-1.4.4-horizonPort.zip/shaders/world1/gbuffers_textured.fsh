#version 120
in float hz_FogFragCoord;
#define THE_END
#include "/program/gbuffers_textured.fsh"