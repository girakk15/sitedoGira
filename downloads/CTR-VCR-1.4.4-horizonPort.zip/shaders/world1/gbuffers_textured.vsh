#version 120
out float hz_FogFragCoord;
#define THE_END
#include "/program/gbuffers_textured.vsh"