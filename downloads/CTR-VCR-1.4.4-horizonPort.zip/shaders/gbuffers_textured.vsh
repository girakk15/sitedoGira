#version 120
out float hz_FogFragCoord;
#include "/program/gbuffers_textured.vsh"