#version 130

in vec2 TexCoords;
in vec2 LightmapCoords;
#ifdef HZ_NFIX_Normal
in vec3 hz_nfix_in_Normal; vec3 Normal;
#else
in vec3 Normal;
#endif
in vec4 Color;

uniform sampler2D texture;

void main(){
    vec4 albedo = texture2D(texture, TexCoords) * Color;
	
    /* DRAWBUFFERS:012 */
    gl_FragData[0] = albedo;
    gl_FragData[1] = vec4(Normal * 0.5f + 0.5f, albedo.a);
    gl_FragData[2] = vec4(LightmapCoords, 1.0f, albedo.a);
}
