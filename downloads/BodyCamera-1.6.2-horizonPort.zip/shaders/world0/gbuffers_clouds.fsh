#version 130
in float hz_FogFragCoord;

#include "/settings.glsl"

varying vec2 TexCoords;
varying vec2 LightmapCoords;
#ifdef HZ_NFIX_Normal
varying vec3 hz_nfix_in_Normal; vec3 Normal;
#else
varying vec3 Normal;
#endif
varying vec4 Color;

uniform vec3 skyColor;
uniform sampler2D texture;
uniform float near, far;
uniform float rainStrength;

void main()
{
	vec4 albedo = texture2D(texture, TexCoords) * Color;
	albedo.a *= 0.6;
	
	float fog;
    fog = clamp((hz_FogFragCoord - far) * (near * 0.1), 0.0f, 1.0f);
	if(gl_Fog.color.rgb != vec3(0.0f))
	{
		albedo.a = mix(albedo.a, 0, fog);
	}
	
	#if GREY_WEATHER == 1
	albedo.a = 0.0;
	#endif
	
	#if TI == 1
	albedo.a = 0.0;
	#endif

	gl_FragData[0] = albedo;
}
