#version 130

out vec2 TexCoords;
out vec4 Color;
out vec2 LightmapCoords;
#ifdef HZ_NFIX_Normal
out vec3 hz_nfix_in_Normal; vec3 Normal;
#else
out vec3 Normal;
#endif

void main() {
    gl_Position = ftransform();
	TexCoords = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	
	LightmapCoords = mat2(gl_TextureMatrix[1]) * gl_MultiTexCoord1.st;
    LightmapCoords = (LightmapCoords * 33.05f / 32.0f) - (1.05f / 32.0f);
	
	Normal = gl_Normal;
	
    Color = gl_Color;
}
