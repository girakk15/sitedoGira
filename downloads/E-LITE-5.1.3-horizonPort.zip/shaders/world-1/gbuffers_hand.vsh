#version 120
#define texture(s, uv) textureLod(s, uv, 0.0)
#define texture2D(s, uv) textureLod(s, uv, 0.0)
#define texture3D(s, uv) textureLod(s, uv, 0.0)
out float hz_FogFragCoord;
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - gbuffers_hand.vsh
Render: Hand opaque objects

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define GBUFFER_HAND
#define NO_SHADOWS

#include "/common/solid_blocks_vertex.glsl"
