#version 130
#define texture(s, uv) textureLod(s, uv, 0.0)
#define texture2D(s, uv) textureLod(s, uv, 0.0)
#define texture3D(s, uv) textureLod(s, uv, 0.0)
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - final.fsh
Render: Final renderer

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define NETHER
#define FINAL_SHADER
#define NO_SHADOWS

/* Config, uniforms, ins, outs */
#include "/common/final_vertex.glsl"

