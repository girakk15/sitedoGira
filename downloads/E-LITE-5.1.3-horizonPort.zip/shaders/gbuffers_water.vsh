#version 120
#define main hz_pack_main
#define HZ_NFIX_binormal
#define HZ_NFIX_tangent
#define texture(s, uv) textureLod(s, uv, 0.0)
#define texture2D(s, uv) textureLod(s, uv, 0.0)
#define texture3D(s, uv) textureLod(s, uv, 0.0)
out float hz_FogFragCoord;
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - gbuffers_water.vsh
Render: Water and translucent blocks

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define USE_BASIC_SH // Sets the use of a "basic" or "generic" shader for custom dimensions, instead of the default overworld shader. This can solve some rendering issues as the shader is closer to vanilla rendering.

#ifdef USE_BASIC_SH
    #define UNKNOWN_DIM
#endif
#define WATER_F

#include "/common/water_blocks_vertex.glsl"


// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_binormal = binormal;
    hz_nfix_in_tangent = tangent;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
