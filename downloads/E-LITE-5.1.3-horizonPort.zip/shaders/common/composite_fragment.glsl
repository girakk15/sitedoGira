#include "/lib/config.glsl"

#if !defined SIMPLE_AUTOEXP
    const bool colortex1MipmapEnabled = true;
#endif

// == Color utils
#ifdef THE_END
    #include "/lib/color_utils_end.glsl"
#elif defined NETHER
    #include "/lib/color_utils_nether.glsl"
#else
    #include "/lib/color_utils.glsl"
#endif

// == Uniforms
uniform sampler2D colortex1;
uniform float far;
uniform float near;
uniform float blindness;
uniform float rainStrength;
uniform float wetness;
uniform sampler2D depthtex0;
uniform int isEyeInWater;
uniform ivec2 eyeBrightnessSmooth;
uniform float frameTime;
uniform float viewWidth;
uniform float viewHeight;
uniform int frameCounter;
uniform vec3 cameraPosition;

#ifdef VOXY
    uniform sampler2D vxDepthTexTrans;
#endif

#if MC_VERSION >= 11900
    uniform float darknessFactor;
#endif

#if VOL_LIGHT == 1 && !defined NETHER
    uniform sampler2D depthtex1;
    uniform vec3 sunPosition;
    uniform vec3 moonPosition;
    uniform float light_mix;
    uniform mat4 gbufferProjectionInverse;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferModelView;
    uniform float vol_mixer;
#endif

#if VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER
    uniform float light_mix;
    uniform mat4 gbufferProjectionInverse;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferModelView;
    uniform float vol_mixer;
    uniform vec3 shadowLightPosition;
    uniform mat4 shadowModelView;
    uniform mat4 shadowProjection;
    uniform sampler2DShadow shadowtex1;

    #if defined COLORED_SHADOW
        uniform sampler2DShadow shadowtex0;
        uniform sampler2D shadowcolor0;
    #endif
#endif

// == Varyings
varying vec2 texcoord;
varying vec3 direct_light_color;
varying vec3 direct_light_strength;
varying float exposure;

#if (VOL_LIGHT == 2) || VOL_LIGHT == 1 && !defined NETHER
    varying vec3 vol_light_color;
    varying vec2 lightpos;
    varying vec3 astro_pos;
#endif

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    varying mat4 modeli_times_projectioni;
#endif

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    varying vec3 v_view_vector;
    varying vec3 v_center_view_vector;
#endif


// == Utility
#include "/lib/basic_utils.glsl"
#include "/lib/depth.glsl"
#include "/lib/luma.glsl"

#if (VOL_LIGHT == 1 || (VOL_LIGHT == 2)) && !defined NETHER
    #include "/lib/dither.glsl"
    #include "/lib/volumetric_light.glsl"
#endif

// == Main function

void main() {
    vec4 block_color = texture2DLod(colortex1, texcoord, 0);
    float d = texture2DLod(depthtex0, texcoord, 0).r;
    float linear_d = ld(d);

    #ifdef VOXY
        float d2 = texture2DLod(vxDepthTexTrans, texcoord * RENDER_SCALE, 0).r;
    #endif

    vec2 eye_bright_smooth = vec2(eyeBrightnessSmooth);

    // Depth to distance
    float screen_distance = linear_d * far * 0.5;
    
    #if defined THE_END || defined NETHER
        #define NIGHT_CORRECTION 1.0
        #define COLOR_CORRECTION dayBlend(vec3(1.0, 0.8, 1.0), vec3(1.0), vec3(1.0, 0.6, 1.0))
    #else
        #define NIGHT_CORRECTION dayBF(0.5, 0.75, 5.0)
        #define COLOR_CORRECTION dayBlend(vec3(1.0, 0.8, 1.0), vec3(1.0), vec3(1.0, 0.6, 1.0))
    #endif

    // Underwater fog
    // Pre-calculating values.
    float water_absorption_exponent_val;
    float eye_brightness_scaled_val;
    vec3 water_light_color_base;

    if (isEyeInWater == 1) {
        // Underwater fog
        // Pre-calculating values.
        float water_absorption_exponent_val = WATER_FOG + (WATER_ABSORPTION * 4.0);
        float eye_brightness_scaled_val = (eye_bright_smooth.y * .8 + 48.0) * 0.004166666666666667;
        vec3 water_light_color_base = NIGHT_CORRECTION * saturate(WATER_COLOR, mix(1.0, 0.25, rainStrength)) * COLOR_CORRECTION * direct_light_strength;
        float x = clamp(1.0 - linear_d, 0.0, 1.0);
        float water_absorption = 1.0 - fastpow(x, water_absorption_exponent_val);

        block_color.rgb = mix(block_color.rgb, water_light_color_base * eye_brightness_scaled_val, water_absorption);

    } else if (isEyeInWater == 2) {
        float lava_f = clamp(linear_d * (far * 0.125), 0.0, 1.0);
        block_color = mix(block_color, vec4(1.0, 0.1, 0.0, 1.0), sqrt(lava_f));
    }

    #if MC_VERSION >= 11900
        if (blindness > .01 || darknessFactor > .01) {
            float mask = step(0.999, linear_d);
            block_color.rgb *= 1.0 - mask;
        }
    #else
        if (blindness > .01) {
            float mask = step(0.999, linear_d);
            block_color.rgb *= 1.0 - mask;
        }
    #endif


    #if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && !defined NETHER)
        #if AA_TYPE > 0
            float dither = shifted_eclectic_r_dither(gl_FragCoord.xy);
        #else
            float dither = r_dither(gl_FragCoord.xy);
        #endif

        float height_factor = clamp(1.0 - (cameraPosition.y / 63.0), 0.0, 1.0);
        height_factor = pow(height_factor, 0.1);
        float cave_influence = height_factor * clamp(1.0 - eyeBrightnessSmooth.y * 0.1, 0.0, 1.0);
        cave_influence = smoothstep(1.0, 0.0, cave_influence);
    #endif

    vec3 block_colorvl;

    #if VOL_LIGHT == 1 && !defined NETHER
        #if defined THE_END
            #if MC_VERSION < 11604
                float vol_light = 0.0;
            #else
                float vol_light = ss_godrays(dither) * 0.4;
            #endif
        #else
            float vol_light = ss_godrays(dither) * cave_influence;
        #endif

        vec3 view_vector = normalize(v_view_vector);
        vec3 center_view_vector = normalize(v_center_view_vector);

        #if defined THE_END
            // Fixed light source position in sky for intensity calculation
            vec3 intermediate_vector =
                normalize((gbufferModelViewInverse * gbufferModelView * vec4(0.0, 0.89442719, 0.4472136, 0.0)).xyz);
            float vol_intensity =
                clamp(dot(center_view_vector, intermediate_vector), 0.0, 1.0);

            vol_intensity *= clamp(dot(view_vector, intermediate_vector), 0.0, 1.0);

            vol_intensity *= 0.666;

            block_colorvl = block_color.rgb + (vol_light_color * vol_light * vol_intensity * 2.0);
        #else
            // Light source position for depth based godrays intensity calculation
            vec3 intermediate_vector =
                normalize((gbufferModelViewInverse * vec4(astro_pos, 0.0)).xyz);
            
            #if ROUND_SUN == 1
                float vol_intensity =
                    clamp(dot(center_view_vector, intermediate_vector) * dayBF(0.5, 2.0, 1.0), 0.0, 1.0);
            #else
                float vol_intensity =
                    clamp(dot(center_view_vector, intermediate_vector), 0.0, 1.0);
            #endif
                float cosTheta = dot(view_vector, intermediate_vector);
                float acos_approx = fastApproxACos(cosTheta);
                float linear = 1.0 - (acos_approx * 0.6366197);
                vol_intensity *= squarePow(linear);
            vol_intensity =
                pow(clamp(vol_intensity, 0.0, 1.0), vol_mixer) * 0.5 * abs(light_mix * 2.0 - 1.0);
            block_colorvl =
                mix(block_color.rgb, vol_light_color * vol_light, vol_intensity * (vol_light  * 0.5 + 0.5) * (1.0 - rainStrength * 0.85));
        #endif
    #else
       block_colorvl = block_color.rgb;
    #endif

    #if VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER
        #if defined COLORED_SHADOW
            vec3 vol_light = get_volumetric_color_light(dither, screen_distance, modeli_times_projectioni);
        #else
            float vol_light = get_volumetric_light(dither, screen_distance, modeli_times_projectioni);
        #endif

        // Volumetric intensity adjustments

        vec3 view_vector = normalize(v_view_vector);

        #if defined THE_END
            // Fixed light source position in sky for volumetrics intensity calculation (The End)
            float vol_intensity = dot(view_vector, normalize((gbufferModelViewInverse * gbufferModelView * vec4(0.0, 0.89442719, 0.4472136, 0.0)).xyz));
        #else
            // Light source position for volumetrics intensity calculation
            float vol_intensity = dot(view_vector, normalize((gbufferModelViewInverse * vec4(shadowLightPosition, 0.0)).xyz));
        #endif

        #if defined THE_END
            vol_intensity =
                ((squarePow(clamp((vol_intensity + .666667) * 0.6, 0.0, 1.0)) * 0.5));
            block_colorvl.rgb += (vol_light_color * vol_light * vol_intensity * 2.0);
        #else
            vol_intensity =
                pow(clamp((vol_intensity + 0.5) * 0.666666666666666, 0.0, 1.0), vol_mixer) * 0.6 * abs(light_mix * 2.0 - 1.0);

            block_colorvl.rgb =
                mix(block_color.rgb, vol_light_color * vol_light, vol_intensity * (vol_light * 0.5 + 0.5) * (1.0 - rainStrength));
        #endif
    #elif VOL_LIGHT != 1
        //block_colorvl = block_color.rgb;
    #endif

    // Dentro de la nieve
    #ifdef BLOOM
        if(isEyeInWater == 3) {
            block_color.rgb =
                mix(block_color.rgb, vec3(0.7, 0.8, 1.0) / exposure, clamp(screen_distance, 0.0, 1.0));
        }
    #else
        if(isEyeInWater == 3) {
            block_color.rgb =
                mix(block_color.rgb, vec3(0.85, 0.9, 0.6), clamp(screen_distance, 0.0, 1.0));
        }
    #endif

    #ifdef BLOOM
        float bloom_luma = smoothstep(0.85, 1.0, luma(block_colorvl * exposure)) * 0.5;

        block_color = clamp(block_color, vec4(0.0), vec4(50.0, 50.0, 50.0, 1.0));
        
        #if REFLECTION_SLIDER > 0 && MATERIAL_GLOSS > 1
            /* DRAWBUFFERS:1246 */
            gl_FragData[0] = vec4(block_colorvl, block_color.a);
            gl_FragData[1] = block_color * bloom_luma;
            gl_FragData[2] = block_color;
            gl_FragData[3] = vec4(exposure, 0.0, 0.0, 0.0);
        #else
            /* DRAWBUFFERS:126 */
            gl_FragData[0] = vec4(block_colorvl, block_color.a);
            gl_FragData[1] = block_color * bloom_luma;
            gl_FragData[2] = vec4(exposure, 0.0, 0.0, 0.0);
        #endif
    #else
        block_colorvl = clamp(block_colorvl, vec3(0.0), vec3(50.0));
        block_color = clamp(block_color, vec4(0.0), vec4(50.0, 50.0, 50.0, 1.0));
        
        #if REFLECTION_SLIDER > 0 && MATERIAL_GLOSS > 1
            /* DRAWBUFFERS:146 */
            gl_FragData[0] = vec4(block_colorvl, block_color.a);
            gl_FragData[1] = block_color;
            gl_FragData[2] = vec4(exposure, 0.0, 0.0, 0.0);
        #else
            /* DRAWBUFFERS:16 */
            gl_FragData[0] = vec4(block_colorvl, block_color.a);
            gl_FragData[1] = vec4(exposure, 0.0, 0.0, 0.0);
        #endif
    #endif
}