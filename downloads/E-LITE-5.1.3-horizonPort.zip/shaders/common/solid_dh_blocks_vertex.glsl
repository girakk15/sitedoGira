#include "/lib/config.glsl"

// == Color utils
#if defined THE_END
    #include "/lib/color_utils_end.glsl"
#elif defined NETHER
    #include "/lib/color_utils_nether.glsl"
#else
    #include "/lib/color_utils.glsl"
#endif

// == Uniforms
uniform ivec2 eyeBrightnessSmooth;
uniform mat4 dhProjection;
uniform mat4 gbufferModelView;
uniform mat4 gbufferModelViewInverse;
uniform vec3 sunPosition;
uniform int isEyeInWater;
uniform float light_mix;
uniform float far;
uniform float rainStrength;
uniform float wetness;
uniform mat4 gbufferProjectionInverse;
uniform int dhRenderDistance;
uniform float viewWidth; 
uniform float viewHeight; 
uniform int frameCounter;
uniform float frameTime;
uniform vec3 skyColor;

#ifdef UNKNOWN_DIM
    uniform sampler2D lightmap;
#endif

#if defined IS_IRIS && defined THE_END && MC_VERSION >= 12109
    uniform float endFlashIntensity;
#endif

// == Varyings
varying vec2 texcoord;
varying vec4 tint_color;
varying vec3 direct_light_color;
varying vec3 candle_color;
varying float direct_light_strength;
varying vec3 omni_light;
varying vec4 position;
varying vec4 sub_position;
varying float fog_adj;
varying float near_fog;
varying vec3 flat_normal;

// == Utility
#if AA_TYPE > 1
    #include "/src/taa_offset.glsl"
#endif

#include "/lib/basic_utils.glsl"
#include "/lib/luma.glsl"

#define FOG_BIOME
#include "/lib/biome_sky.glsl"
//#include "/lib/downscale.glsl"

// == Main function

void main() {
    vec2 eye_bright_smooth = vec2(eyeBrightnessSmooth);
    float visible_sky;
    vec3 hi_sky_color;
    vec3 pure_hi_sky_color;

    #include "/src/basiccoords_vertex_dh.glsl"
    #include "/src/position_vertex_dh.glsl"
    //resize_vertex(gl_Position);
    #include "/src/hi_sky.glsl"
    #include "/src/light_vertex_dh.glsl"
    #include "/src/fog_vertex_dh.glsl"

    flat_normal = normal;
}
