#include "/lib/config.glsl"

// == Color utils

#ifdef THE_END
    #include "/lib/color_utils_end.glsl"
#else
    #include "/lib/color_utils.glsl"
#endif

// == Uniforms

uniform float rainStrength;
uniform float wetness;
uniform ivec2 eyeBrightnessSmooth;

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    uniform int isEyeInWater;
#endif

#if VOL_LIGHT == 1 && !defined NETHER
    uniform float light_mix;
    uniform vec3 sunPosition;
    uniform vec3 moonPosition;
    uniform mat4 gbufferProjection;
#endif

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferProjectionInverse;
    uniform mat4 gbufferModelView;
#endif

uniform sampler2D colortex1;
uniform sampler2D gaux3;
uniform float viewWidth;
uniform float viewHeight;
uniform float frameTime;
uniform float frameTimeCounter;

// == Varying

varying vec2 texcoord;
varying vec3 direct_light_color;
varying vec3 direct_light_strength;

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    varying vec3 vol_light_color;
#endif

varying float exposure;

#if VOL_LIGHT == 1 && !defined NETHER
    varying vec2 lightpos;
    varying vec3 astro_pos;
#endif

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    varying vec3 v_view_vector;
    varying vec3 v_center_view_vector;
#endif

#if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
    varying mat4 modeli_times_projectioni;
#endif

// == Utility

#include "/lib/luma.glsl"

// == Main function

void main() {
    gl_Position = gl_ModelViewProjectionMatrix * gl_Vertex;
    texcoord = gl_MultiTexCoord0.xy;

    vec2 eye_bright_smooth = vec2(eyeBrightnessSmooth);

    direct_light_color = dayBlgcy(LIGHT_SUNSET_COLOR, LIGHT_DAY_COLOR, LIGHT_NIGHT_COLOR);
    direct_light_color = mix(direct_light_color, ZENITH_SKY_RAIN_COLOR * luma(direct_light_color), rainStrength);
    direct_light_strength = gray(direct_light_color * 2);

    // Exposure
    #if !defined SIMPLE_AUTOEXP
        float mipmap_level = log2(min(viewWidth * RENDER_SCALE , viewHeight * RENDER_SCALE));

        vec3 exposure_col = texture2DLod(colortex1, vec2(0.5 * RENDER_SCALE), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.25 * RENDER_SCALE), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.75 * RENDER_SCALE), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.25 * RENDER_SCALE, 0.75 * RENDER_SCALE), mipmap_level).rgb;
        exposure_col += texture2DLod(colortex1, vec2(0.75 * RENDER_SCALE, 0.25 * RENDER_SCALE), mipmap_level).rgb;
        
        exposure = clamp(luma(exposure_col), 0.0005, 100.0);

        float prev_exposure = texture2D(gaux3, vec2(0.5)).r;

        exposure = (exp(-exposure) * 3.25) + 0.6;
        exposure = mix(exposure, prev_exposure, exp(-frameTime * (1.0 / mix(0.25, 1.0, min(frameTimeCounter * 0.5, 1.0)))));
    #else
        exposure = 1.0;
    #endif

    #if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
        float vol_attenuation;
        if(isEyeInWater == 0) {
            vol_attenuation = 1.0;
        } else {
            vol_attenuation = 0.5 + (eye_bright_smooth.y * 0.002);
        }

        #ifdef THE_END
            vol_light_color = saturate(LIGHT_SUNSET_COLOR * 0.75, 2.0) * vol_attenuation;
        #else
            vol_light_color = dayBlend(
                saturate(LIGHT_SUNSET_COLOR * dayBF(1.0, 1.0, 0.0), mix(dayBFlgcy(0.75, 1.0, 0.0), 0.0, rainStrength)) * vol_attenuation,
                saturate(LIGHT_DAY_COLOR, 0.1) * vol_attenuation * 0.75 * dayBF(0.0, 1.0, 1.0),
                LIGHT_NIGHT_COLOR * 0.85);
        #endif
    #endif

    #if VOL_LIGHT == 1 && !defined NETHER
        astro_pos = sunPosition * smoothstep(0.1, 0.8, light_mix) * 2.0 + moonPosition;
        vec4 tpos = vec4(astro_pos, 1.0) * gbufferProjection;
        tpos = vec4(tpos.xyz / tpos.w, 1.0);
        vec2 pos1 = tpos.xy / tpos.z;
        lightpos = pos1 * 0.5 + 0.5;
        lightpos *= RENDER_SCALE;
    #endif

    #if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
        vec4 clip_pos = vec4(gl_MultiTexCoord0.xy * 2.0 - 1.0, 1.0, 1.0);
        vec4 view_pos = gbufferProjectionInverse * clip_pos;
        v_view_vector = (gbufferModelViewInverse * view_pos).xyz; 
        v_center_view_vector = (gbufferModelViewInverse * gbufferProjectionInverse * vec4(0.0, 0.0, 1.0, 1.0)).xyz;
    #endif

    #if (VOL_LIGHT == 1 && !defined NETHER) || (VOL_LIGHT == 2 && defined SHADOW_CASTING && !defined NETHER)
        modeli_times_projectioni = gbufferModelViewInverse * gbufferProjectionInverse;
    #endif
}
