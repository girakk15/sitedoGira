#version 120
#define texture(s, uv) textureLod(s, uv, 0.0)
#define texture2D(s, uv) textureLod(s, uv, 0.0)
#define texture3D(s, uv) textureLod(s, uv, 0.0)
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - composite.fsh
Render: Bloom and volumetric light

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define COMPOSITE_SHADER

#include "/common/composite_vertex.glsl"
