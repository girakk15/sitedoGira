#version 120
#define main hz_pack_main
#define HZ_NFIX_binormal
#define HZ_NFIX_tangent
out float hz_FogFragCoord;
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - gbuffers_water.vsh
Render: Water and translucent blocks

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define WATER_F

#include "/common/water_blocks_vertex.glsl"


// face-normals (horizon-shaderport)
#undef main
varying vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_binormal = binormal;
    hz_nfix_in_tangent = tangent;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
