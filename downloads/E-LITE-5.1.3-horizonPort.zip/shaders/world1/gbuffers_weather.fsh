#version 120
in float hz_FogFragCoord;
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - gbuffers_weather.fsh
Render: Weather

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define THE_END
#define GBUFFER_WEATHER
#define SPECIAL_TRANS

#include "/common/solid_blocks_fragment.glsl"