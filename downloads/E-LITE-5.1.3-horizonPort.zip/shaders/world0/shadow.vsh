#version 120
#include "/lib/extensions.glsl"
/* MakeUp - E-LITE shaders 5 - shadow.fsh
Render: Shadowmap

Javier Garduño - GNU Lesser General Public License v3.0
*/

#define SHADOW_SHADER

#include "/common/shadow_vertex.glsl"
