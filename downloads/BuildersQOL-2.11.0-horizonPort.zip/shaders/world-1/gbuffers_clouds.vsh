#version 120
// horizon-shaderport clouds-off: the pack sets clouds=off; this program draws nothing
void main() {
    gl_Position = vec4(2.0, 2.0, 2.0, 1.0);
}
