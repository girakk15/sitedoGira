#version 120
// horizon-shaderport clouds-off: the pack sets clouds=off; this program draws nothing
void main() {
    discard;
}
