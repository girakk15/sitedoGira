Welcome! If you're reading this, then you probably want to edit my shader pack.
I'm completely cool with this. In fact, to help you get started faster, here's an overview of how stuff works:
If you're on an old version of minecraft and just want to know all the places where you need to change a specific option, you can skip to the options section below.
If on the other hand you want to alter this pack for your own *personal* use, continue reading.

The first thing I'd like to point out is that in this download, there's a "shaders" folder, and a "src" folder.
The src folder is what I modify when developing these shaders, and the shaders folder is what my compile script spits out.
The main difference between them is that my compile script automatically collapses all #include's,
because the original shaders mod didn't have support for them and I never bothered to remove this feature in newer versions.
It also removes useless code, unused uniforms/constants/methods, etc... and generates this readme file.
As such, if you want to modify my shaders, I'd recommend removing the shaders folder, and renaming the src folder to "shaders" instead.
This is not required, as both folders *should* work identically; but it is recommended since most lib files are used in multiple places.

If the change you want to make is as simple as just changing a number, there's a good chance I already have support for that.
See /shaders/lib/magicNumbers.glsl for all the magic numbers which apply to all dimensions.
See /shaders/world(number)/lib/magicNumbers.glsl for all the magic numbers which only apply to specific dimensions.
If the number you want to change isn't in any of these files, let me know and I'll add it.

composite.fsh controls rendering for most opaque objects. This includes main light levels, held lights, fog, etc...
It also does some preparations for infinite oceans, which are mostly handled in composite1.fsh.
Speaking of infinite oceans, they're also partially handled in skybasic; as it writes 0% opacity to the gaux1 buffer below the horizon.
This acts as the flag for where composite should fix colors/normal data, so that composite1 has the correct values.
Skybasic also handles most of the sky colors (see calculateSkyColor()). It also handles fancy stars and galaxies.
sunPathRotation is also set there. If you plan on changing this, you'll need to set it in both skybasic.fsh AND vsh.
This is due to a bug in optifine, where sun/moon positions are actually one frame behind where they should be.
I fix this by calculating their positions manually; but to do that, sunPathRotation needs to be the same in the fsh and vsh stages.

A few effects are handled in the gbuffers files, such as:
gbuffers_block handles ender portals
gbuffers_entities handles rainbow XP, circular shadows, and entity coloring (the red tint when an entity take damage)
gbuffers_terrain handles all of the foliage effects, as well as wet dirt, randomized lava brightness, and lava waves (in the nether)
gbuffers_weather handles waving rain

gbuffers_water and hand handle most of the transparent stuff, in the same way that composite handles opaque stuff. This includes lighting/fog/etc...
Both of them write normal data to gnormal, which is used in composite1.fsh for sun/sky reflections.
hand also handles hand sway.

Most of the other fancy effects (like clouds, water refractions, etc...) are handled in composite1.
The only exceptions being ender nebulae/stars and twilight forest auroras, which are handled in world1/composite.fsh and world7/composite.fsh respectively.

Composite2 and final are used for blur effects. 2 programs are needed because I'm using a technique called 2-pass blurring.
First, blur horizontally, then blur vertically. Sounds simple, but is MUCH better on framerate than trying to do both at once.
This is because only doing horizontal blur requires ~(2 * radius) sample points, as does vertical blur.
Therefore, we need ~(4 * radius) sample points total.
If we did it all in one pass, we'd need ~(2 * radius) ^ 2 sample points, which is much larger.

That's all the effects, now for the used buffers:

gcolor: Stores color of opaque objects.
composite: Stores the color of transparent objects, and the opacity of the closest transparent object to the camera.
gnormal: Stores normal vectors of the closest transparent object to the camera (used for refractions and reflections)
gaux1: Red and green store block light and skylight of opaque objects. Blue is always 1.0.
	An opacity of 0.5 flags it as being part of the sky.
	An opacity of 0.0 flags it as being part of the lower half of the sky. (for infinite oceans)
gaux2: Red and green store block light and skylight of the closest transparent object to the camera.
	Used for not doing reflections when underground.
	The blue channel also stores block data, used for block-specific effects like better stained glass, water refractions, ice scattering, etc...
gaux3: Red stores the combined opacity of all transparent objects.

However, after all the composite programs run, these usages change quite drastically.

composite (the program, not the buffer) will first transfer the red channel of gaux3 (combined opacity of all transparent objects) to the alpha channel of gcolor.
	It also updates gnormal and gaux2 data for infinite oceans.
Next, composite1 will store the final color and blur radius in gaux3.
composite2 then applies horizontal blurring to gaux3, and writes the new horizontally blurred color to composite (the buffer, not the program).
Lastly: final will apply vertical blurring to composite, and write the result directly to the screen.

With all this in mind, you should have a fairly decent grasp on where everything is.

If you have any other questions about how specific features are implemented, or why I chose the equations I did, you can ask me about it on discord: https://discord.gg/FMghhxk
I'd be happy to help you figure stuff out, and if I like your changes, they might even get implemented officially :)

With all that out of the way, here's all the options you can set, and where to find them: Alphabetized here for convenience.

################################################################################
################################ Config options ################################
################################################################################

actualSeaLevel (localization missing):
	Description: water source blocks are 8/9'ths of a block tall, so SEA_LEVEL - 1/9.
	Default Value: SEA_LEVEL - 0.1111111111111111
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.fsh, composite1.fsh

Ambient Occlusion:
	Internal name: GRASS_AO
	Description: Adds ambient occlusion to tallgrass/flowers/etc... Works best with "Remove Y Offset" enabled.
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_terrain.fsh/vsh
		In world0: gbuffers_terrain.fsh/vsh
		In world1: gbuffers_terrain.fsh/vsh
		In world7: gbuffers_terrain.fsh/vsh

ambientLightColor (localization missing):
	Default Value: vec3(0.1, 0.05, 0.2)
	Found in:
		In world1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

ambientLightColorInOtherBiomes (localization missing):
	Default Value: vec3(0.125,   0.03125, 0.03125)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

ambientLightColorInSoulSandValleys (localization missing):
	Default Value: vec3(0.03125, 0.125,   0.125)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

ambientVibrantColor (localization missing):
	Default Value: vec3(1.0, 0.75, 1.5)
	Found in:
		In world1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

ambientVibrantColorInOtherBiomes (localization missing):
	Default Value: vec3(1.5,  1.0, 0.75)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

ambientVibrantColorInSoulSandValleys (localization missing):
	Default Value: vec3(0.75, 1.0, 1.5)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Average Cloud Density:
	Internal name: CLOUD_DENSITY_AVERAGE
	Description: Average cloud density. Higher value means more clouds
	Default Value: 0.0
	Recommended values: -2.0 ~ 2.0
	Found in:
		In world0: composite1.vsh

Background:
	Internal name: END_PORTAL_BACKGROUND_END
	Description: 1: Use overworld fog color. 2: Use end background.
	Default Value: 1
	Recommended values: 1 2
	Found in:
		In world1: gbuffers_block.fsh

Background:
	Internal name: END_PORTAL_BACKGROUND_TF
	Description: 1: Use overworld fog color. 2: Use end background.
	Default Value: 2
	Recommended values: 1 2
	Found in:
		In world7: gbuffers_block.fsh

Background:
	Internal name: END_PORTAL_BACKGROUND_NETHER
	Description: 1: Use overworld fog color. 2: Use end background.
	Default Value: 2
	Recommended values: 1 2
	Found in:
		In world-1: gbuffers_block.fsh

Background:
	Internal name: END_PORTAL_BACKGROUND_OVERWORLD
	Description: 1: Use overworld fog color. 2: Use end background.
	Default Value: 2
	Recommended values: 1 2
	Found in:
		In world0: gbuffers_block.fsh

Better Beacon Beams:
	Internal name: FANCY_BEACONS
	Description: Builderb0y's better beacon beams bring big bright beautiful beacon beams to all biomes, bro
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_beaconbeam.fsh/vsh
		In world0: gbuffers_beaconbeam.fsh/vsh
		In world1: gbuffers_beaconbeam.fsh/vsh
		In world7: gbuffers_beaconbeam.fsh/vsh

Better Stained Glass:
	Internal name: ALT_GLASS
	Description: Uses alternate blending method for stained glass which looks more like real stained glass
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blockLightColorFar (localization missing):
	Description: color of block lights when the player is far away from a light source.
	Default Value: vec3(1.0,   0.5,   0.15)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blockLightColorFarInSoulSandValleys (localization missing):
	Description: color of block lights in soul sand valleys when the player is far away from a light source.
	Default Value: vec3(0.25,    0.75,    1.5)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blockLightColorNear (localization missing):
	Description: color of block lights when the player is near a light source.
	Default Value: vec3(1.0,   0.85,  0.7)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blockLightColorNearInSoulSandValleys (localization missing):
	Description: color of block lights in soul sand valleys when the player is near a light source.
	Default Value: vec3(0.8,     1.1,     1.4)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blocklightVibrantColorFar (localization missing):
	Description: Vibrant color for block lights when standing far away from a light source.
	Default Value: vec3(1.4, 1.0, 0.8)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blocklightVibrantColorNear (localization missing):
	Description: Vibrant color for block lights when standing near a light source.
	Default Value: vec3(1.2, 1.1, 1.0)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blockVibrantColorFarInSoulSandValleys (localization missing):
	Description: vibrant color for block lights in soul sand valleys when the player is far away from a light source.
	Default Value: vec3(0.8,  1.0, 1.4)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

blockVibrantColorNearInSoulSandValleys (localization missing):
	Description: vibrant color for block lights in soul sand valleys when the player is near a light source.
	Default Value: vec3(1.0,  1.1, 1.2)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Blur Samples:
	Internal name: BLUR_QUALITY
	Description: Maximum number of sample points to use for blurring. Higher limit = higher performance impact!
	Default Value: 10
	Recommended values: 5 ~ 25
	Found in:
		In world-1: composite2.fsh, final.fsh
		In world0: composite2.fsh, final.fsh
		In world1: composite2.fsh, final.fsh
		In world7: composite2.fsh, final.fsh

Bright Portal Fix:
	Internal name: BRIGHT_PORTAL_FIX
	Description: Enable this if end portals are 16x brighter than they should be
	Default Value: false
	Recommended values: true false
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: gbuffers_block.fsh
		In world1: gbuffers_block.fsh
		In world7: gbuffers_block.fsh

Bright Water:
	Internal name: BRIGHT_WATER
	Description: Overrides light levels under water to be higher
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Clear Water:
	Internal name: CLEAR_WATER
	Description: Overwrites water texture to be completely transparent
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_water.fsh
		In world0: gbuffers_water.fsh
		In world1: gbuffers_water.fsh
		In world7: gbuffers_water.fsh

Cloud Density Variance:
	Internal name: CLOUD_DENSITY_VARIANCE
	Description: How far above or below the average cloud density will go
	Default Value: 1.5
	Recommended values: 0.0 ~ 2.0
	Found in:
		In world0: composite1.vsh

Cloud Normals:
	Internal name: CLOUD_NORMALS
	Description: Dynamically light clouds based on weather they're facing towards or away from the sun. Mild performance impact!
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite1.fsh/vsh

cloudBaseColorDuringSunnyDays (localization missing):
	Default Value: vec3(0.48, 0.5, 0.55)
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: composite1.vsh, gbuffers_block.fsh
		In world1: gbuffers_block.fsh

cloudIlluminationColorFromFullMoon (localization missing):
	Default Value: vec3(0.1,  0.15, 0.25)
	Found in:
		In world0: composite1.fsh/vsh

cloudIlluminationColorFromLightning (localization missing):
	Default Value: vec3(0.9,  0.95, 1.0 )
	Found in:
		In world0: composite1.fsh/vsh

cloudIlluminationColorFromNewMoon (localization missing):
	Default Value: vec3(0.01, 0.02, 0.03)
	Found in:
		In world0: composite1.fsh/vsh

cloudIlluminationColorWhenRaining (localization missing):
	Default Value: vec3(0.45, 0.5, 0.6)
	Found in:
		In world0: composite1.vsh

cloudIlluminationColorWhenSunny (localization missing):
	Default Value: vec3(1.0,  1.0, 1.0)
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: composite1.vsh, gbuffers_block.fsh
		In world1: gbuffers_block.fsh

Clouds:
	Internal name: END_PORTAL_CLOUDS_END
	Description: 0: No clouds. 1: Use overworld clouds. 2: Use void clouds.
	Default Value: 1
	Recommended values: 0 1 2
	Found in:
		In world1: gbuffers_block.fsh

Clouds:
	Internal name: CLOUDS
	Description: 3D clouds (partially volumetric too). Mild performance impact!
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite1.fsh/vsh, gbuffers_weather.fsh, gbuffers_weather.vsh

Clouds:
	Internal name: END_PORTAL_CLOUDS_OVERWORLD
	Description: 0: No clouds. 1: Use overworld clouds. 2: Use void clouds.
	Default Value: 2
	Recommended values: 0 1 2
	Found in:
		In world0: gbuffers_block.fsh

Clouds:
	Internal name: END_PORTAL_CLOUDS_TF
	Description: 0: No clouds. 1: Use overworld clouds. 2: Use void clouds.
	Default Value: 2
	Recommended values: 0 1 2
	Found in:
		In world7: gbuffers_block.fsh

Clouds:
	Internal name: END_PORTAL_CLOUDS_NETHER
	Description: 0: No clouds. 1: Use overworld clouds. 2: Use void clouds.
	Default Value: 2
	Recommended values: 0 1 2
	Found in:
		In world-1: gbuffers_block.fsh

Custom Sky Fix:
	Internal name: CUSTOM_SKY_FIX
	Description: Disables sun fadeout near the horizon when infinite oceans are enabled. Enable this if your resource pack's custom skys turn black near the horizon.
	Default Value: false
	Recommended values: true false
	Found in:
		In world0: gbuffers_skytextured.fsh

Density Multiplier:
	Internal name: FOG_DENSITY_MULTIPLIER_OVERWORLD
	Description: How much overall fog there is in the overworld.
	Default Value: 1.00
	Recommended values: 0.10 ~ 10.00
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_water.fsh

Density Multiplier:
	Internal name: FOG_DENSITY_MULTIPLIER_NETHER
	Description: How much overall fog there is in the nether
	Default Value: 1.0
	Recommended values: 0.05 ~ 10.0
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_water.fsh

Distance Multiplier:
	Internal name: FOG_DISTANCE_MULTIPLIER_END
	Description: How far away fog starts to appear in the end
	Default Value: 0.25
	Recommended values: 0.05 ~ 10.0
	Found in:
		In world1: composite.fsh, composite1.fsh, gbuffers_water.fsh

Distance Multiplier:
	Internal name: FOG_DISTANCE_MULTIPLIER_TF
	Description: How far away fog starts to appear in the twilight forest
	Default Value: 0.25
	Recommended values: 0.05 ~ 10.0
	Found in:
		In world7: composite.fsh, composite1.fsh, gbuffers_water.fsh

DOF Strength:
	Internal name: DOF_STRENGTH
	Description: Blurs things that are at a different distance than whatever's in the center of your screen
	Default Value: 0
	Recommended values: 0 ~ 25
	Found in:
		In world-1: composite1.fsh/vsh
		In world0: composite1.fsh/vsh
		In world1: composite1.fsh/vsh
		In world7: composite1.fsh/vsh

dragonEggJumpAttemptsPerSecond (localization missing):
	Default Value: 2.0
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

dragonEggJumpDecaySpeed (localization missing):
	Default Value: 3.14159265359
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

dragonEggJumpSuccessChance (localization missing):
	Default Value: 0.25
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

dragonEggMaxJumpAmount (localization missing):
	Default Value: 0.5
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

dragonEggMinJumpAmount (localization missing):
	Default Value: 0.25
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

dragonEggRotationSpeed (localization missing):
	Default Value: 4.0
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Dynamic Light Flicker:
	Internal name: DYNAMIC_LIGHT_FLICKER
	Description: How much certain dynamic lights (like torches) will flicker
	Default Value: 8
	Recommended values: 0 ~ 64
	Found in:
		In world-1: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh
		In world0: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh
		In world1: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh
		In world7: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh

Dynamic Light Vignette:
	Internal name: DYNAMIC_LIGHT_VIGNETTE
	Description: Reduces the brightness of dynamic light around edges the of your screen
	Default Value: 50
	Recommended values: 0 ~ 100
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Dynamic Lights:
	Internal name: DYNAMIC_LIGHTS
	Description: Holding blocks that emit light will light up their surroundings
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world0: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world1: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world7: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_water.fsh, gbuffers_water.vsh

Enable Blur:
	Internal name: BLUR_ENABLED
	Description: Is blur enabled at all?
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite1.fsh/vsh, composite2.fsh, final.fsh
		In world0: composite1.fsh/vsh, composite2.fsh, final.fsh
		In world1: composite1.fsh/vsh, composite2.fsh, final.fsh
		In world7: composite1.fsh/vsh, composite2.fsh, final.fsh

Enabled:
	Internal name: END_PORTAL_EFFECTS_TF
	Description: Enables fancy effects for end portals
	Default Value: true
	Recommended values: true false
	Found in:
		In world7: gbuffers_block.fsh

Enabled:
	Internal name: END_PORTAL_EFFECTS_NETHER
	Description: Enables fancy effects for end portals
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_block.fsh

Enabled:
	Internal name: END_PORTAL_EFFECTS_OVERWORLD
	Description: Enables fancy effects for end portals
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_block.fsh

Enabled:
	Internal name: END_PORTAL_EFFECTS_END
	Description: Enables fancy effects for end portals
	Default Value: true
	Recommended values: true false
	Found in:
		In world1: gbuffers_block.fsh

End (in darkness):
	Internal name: EYE_ADJUST_END_DARK
	Description: Brightness multiplier for the whole screen when standing in darkness in the end
	Default Value: 1.5
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world1: composite1.vsh

End (in light):
	Internal name: EYE_ADJUST_END_LIGHT
	Description: Brightness multiplier for the whole screen when standing in bright light in the end
	Default Value: 1.0
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world1: composite1.vsh

End Desaturation:
	Internal name: DESATURATE_END
	Description: Amount to desaturate the end dimension
	Default Value: 0.25
	Recommended values: 0.00 ~ 1.00
	Found in:
		In world1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

End Fog:
	Internal name: FOG_ENABLED_END
	Description: Enables fog in the end
	Default Value: false
	Recommended values: true false
	Found in:
		In world1: composite.fsh, composite1.fsh, gbuffers_water.fsh

Ender Arcs:
	Internal name: ENDER_ARCS
	Description: Adds bolts of plasma that arc through the nebulae. Requires ender nebulae to be enabled!
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: gbuffers_block.fsh
		In world1: composite.fsh, gbuffers_block.fsh
		In world7: gbuffers_block.fsh

Ender Nebulae:
	Internal name: ENDER_NEBULAE
	Description: Adds animated nebulae to the background of the end dimension
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: gbuffers_block.fsh
		In world1: composite.fsh, gbuffers_block.fsh
		In world7: gbuffers_block.fsh

Ender Stars:
	Internal name: ENDER_STARS
	Description: Adds blinking stars to the background of the end dimension. Stackable with nebulae/plasma.
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: gbuffers_block.fsh
		In world1: composite.fsh, gbuffers_block.fsh
		In world7: gbuffers_block.fsh

Fancy Stars:
	Internal name: FANCY_STARS
	Description: Improved stars in the overworld
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_skybasic.fsh

Fog Height Multiplier:
	Internal name: FOG_HEIGHT_MULTIPLIER_OVERWORLD
	Description: Controls how much denser fog is at lower altitudes
	Default Value: 32.0
	Recommended values: 16.0 ~ 1024.0
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_water.fsh

Foreground:
	Internal name: END_PORTAL_FOREGROUND_END
	Description: 0: No foreground image. 1: Use overworld screenshot. 2: Use end island screenshot.
	Default Value: 1
	Recommended values: 0 1 2
	Found in:
		In world1: gbuffers_block.fsh

Foreground:
	Internal name: END_PORTAL_FOREGROUND_TF
	Description: 0: No foreground image. 1: Use overworld screenshot. 2: Use end island screenshot.
	Default Value: 2
	Recommended values: 0 1 2
	Found in:
		In world7: gbuffers_block.fsh

Foreground:
	Internal name: END_PORTAL_FOREGROUND_NETHER
	Description: 0: No foreground image. 1: Use overworld screenshot. 2: Use end island screenshot.
	Default Value: 2
	Recommended values: 0 1 2
	Found in:
		In world-1: gbuffers_block.fsh

Foreground:
	Internal name: END_PORTAL_FOREGROUND_OVERWORLD
	Description: 0: No foreground image. 1: Use overworld screenshot. 2: Use end island screenshot.
	Default Value: 2
	Recommended values: 0 1 2
	Found in:
		In world0: gbuffers_block.fsh

Galaxies:
	Internal name: GALAXIES
	Description: Galaxies visible at night in the overworld, with even more stars inside them
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_skybasic.fsh

Glass Blur:
	Internal name: GLASS_BLUR
	Description: Blurs things behind stained glass
	Default Value: 8
	Recommended values: 0 ~ 25
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Glass Border Opacity:
	Internal name: THRESHOLD_ALPHA
	Description: Anything above this opacity counts as part of the border of stained glass, and will not apply blur/reflection effects
	Default Value: 0.6
	Recommended values: 0.15 ~ 0.95
	Found in:
		In world-1: gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: gbuffers_hand_water.fsh, gbuffers_water.fsh

goldenOffset0 (localization missing):
	Description: 2.39996322972865332
	Default Value: vec2( 0.675490294261524, -0.73736887807832 )
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh

goldenOffset1 (localization missing):
	Description: 4.79992645945731
	Default Value: vec2(-0.996171040864828,  0.087425724716963)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh

goldenOffset2 (localization missing):
	Description: 7.19988968918596
	Default Value: vec2( 0.793600751291696,  0.608438860978863)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh

goldenOffset3 (localization missing):
	Description: 9.59985291891461
	Default Value: vec2(-0.174181950379306, -0.98471348531543 )
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh

goldenOffset4 (localization missing):
	Description: 11.9998161486433
	Default Value: vec2(-0.53672805262632,   0.843755294812399)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_beaconbeam.fsh, gbuffers_block.fsh

goldenOffset5 (localization missing):
	Description: 14.3997793783719
	Default Value: vec2( 0.965715074375778, -0.259604304901489)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_block.fsh

goldenOffset6 (localization missing):
	Description: 16.7997426081006
	Default Value: vec2(-0.887448429245268, -0.460907024713344)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite1.fsh, gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh
		In world7: composite1.fsh, gbuffers_block.fsh

goldenOffset7 (localization missing):
	Description: 19.1997058378292
	Default Value: vec2( 0.343038630874082,  0.939321296324125)
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_block.fsh
		In world1: composite.fsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh
		In world7: gbuffers_block.fsh

goldenOffset8 (localization missing):
	Description: 21.5996690675579
	Default Value: vec2( 0.38155640847493,  -0.924345556137807)
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite1.fsh/vsh

goldenOffset9 (localization missing):
	Description: 23.9996322972865
	Default Value: vec2(-0.905734272555614, -0.04619144594037 )
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite1.fsh/vsh

Hand Sway:
	Internal name: IDLE_HANDS
	Description: Makes your hands sway back and forth in 1st person, like they do in 3rd person
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_armor_glint.vsh, gbuffers_hand.vsh, gbuffers_hand_water.vsh
		In world0: gbuffers_armor_glint.vsh, gbuffers_hand.vsh, gbuffers_hand_water.vsh
		In world1: gbuffers_armor_glint.vsh, gbuffers_hand.vsh, gbuffers_hand_water.vsh
		In world7: gbuffers_armor_glint.vsh, gbuffers_hand.vsh, gbuffers_hand_water.vsh

Hardcore Darkness:
	Internal name: HARDCORE_DARKNESS
	Description: 0 (Off): Normal visibility at night. 1 (On): Complete darkness at night. 2 (Moon phase) Nighttime brightness is determined by the current phase of the moon.
	Default Value: 0
	Recommended values: 0 1 2
	Found in:
		In world0: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh

Heat Refraction:
	Internal name: HEAT_REFRACTION
	Description: How much the screen jiggles around in the nether, or when in lava
	Default Value: 1.00
	Recommended values: 0.00 ~ 5.00
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_block.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh
		In world0: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh, gbuffers_clouds.fsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_skybasic.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world1: composite.fsh, composite1.fsh, gbuffers_block.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh

heatRefractionInBasaltDeltas (localization missing):
	Default Value: HEAT_REFRACTION * 2.0
	Found in:
		In world-1: composite1.fsh

heatRefractionScale (localization missing):
	Default Value: 0.125
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

heatRefractionSpeed (localization missing):
	Default Value: 0.125
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Humidity Offset:
	Internal name: HUMIDITY_OFFSET
	Description: Higher number = lusher grass. Lower number = dryer grass
	Default Value: 1.1
	Recommended values: 0.5 ~ 1.25
	Found in:
		In world0: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Ice Blur:
	Internal name: ICE_BLUR
	Description: Blurs things behind ice
	Default Value: 4
	Recommended values: 0 ~ 25
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Ice Normals:
	Internal name: ICE_NORMALS
	Description: Distorts things reflected by ice. Has no effect when reflections are disabled!
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite1.fsh
		In world7: composite1.fsh

Ice Refractions:
	Internal name: ICE_REFRACT
	Description: Distorts things behind ice
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

iceNoiseScale (localization missing):
	Default Value: 1.0
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Infinite Oceans:
	Internal name: INFINITE_OCEANS
	Description: Simulates water out to the horizon instead of just your render distance.
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_skybasic.fsh, gbuffers_skytextured.fsh

invNoiseRes (localization missing):
	Default Value: 1.0 / float(noiseTextureResolution)
	Found in:
		In world-1: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world0: composite.vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_skybasic.fsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.vsh, gbuffers_weather.vsh
		In world1: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.vsh
		In world7: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.vsh

Jumping Dragon Eggs:
	Internal name: JUMPING_DRAGON_EGGS
	Description: Makes dragon eggs jump and wobble, as if they were about to hatch
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

lavaOverlayBaseColor (localization missing):
	Default Value: vec3(1.0,   0.5, 0.0)
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

lavaOverlayHeatRefractionOffsetMultiplier (localization missing):
	Default Value: lavaOverlayResolution * 2.0
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

lavaOverlayNoiseColor (localization missing):
	Default Value: vec3(0.375, 0.5, 0.5)
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

lavaOverlayResolution (localization missing):
	Default Value: 24.0
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_block.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh
		In world0: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh, gbuffers_clouds.fsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_skybasic.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world1: composite.fsh, composite1.fsh, gbuffers_block.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh

Legacy Sugarcane:
	Internal name: LEGACY_SUGARCANE
	Description: Removes biome coloring from sugar cane
	Default Value: false
	Recommended values: true false
	Found in:
		In world0: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Lunar Fadeout Radius:
	Internal name: EXCLUSION_RADIUS
	Description: Radius around the moon at which fancy stars/galaxies stop rendering
	Default Value: 1.0
	Recommended values: 0.5 ~ 2.0
	Found in:
		In world0: gbuffers_skybasic.fsh

moonGlowColor (localization missing):
	Description: Mixed with sky color based on distance from moon
	Default Value: vec3(0.075, 0.1,   0.2 )
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite1.fsh, gbuffers_skybasic.fsh

Nether (in darkness):
	Internal name: EYE_ADJUST_NETHER_DARK
	Description: Brightness multiplier for the whole screen when standing in darkness in the nether
	Default Value: 2.5
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world-1: composite1.vsh

Nether (in light):
	Internal name: EYE_ADJUST_NETHER_LIGHT
	Description: Brightness multiplier for the whole screen when standing in bright light in the nether
	Default Value: 1.5
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world-1: composite1.vsh

Nether Fog:
	Internal name: FOG_ENABLED_NETHER
	Description: Enables fog in the nether
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_water.fsh

Nether Lava Level:
	Internal name: NETHER_LAVA_LEVEL
	Description: Y level at which lava waves happen. Also controls some soul fire integration logic.
	Default Value: 32.0
	Recommended values: 0.0 ~ 256.0
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh

Nether Lava Waves:
	Internal name: LAVA_WAVE_STRENGTH
	Description: Adds waves to the nether lava oceans
	Default Value: 100
	Recommended values: 0 ~ 100
	Found in:
		In world-1: gbuffers_terrain.vsh

Night Desaturation:
	Internal name: DESATURATE_NIGHT
	Description: Amount to desaturate the world at night
	Default Value: 0.50
	Recommended values: 0.00 ~ 1.00
	Found in:
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

nightSkyColor (localization missing):
	Description: Added to sky color at night to avoid it being completely black
	Default Value: vec3(0.02,  0.025, 0.05)
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

nightVisionLightColor (localization missing):
	Default Value: vec3(0.375, 0.375, 0.5)
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

noiseTextureResolution (localization missing):
	Default Value: 256
	Found in:
		In world-1: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world0: composite.vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_skybasic.fsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.vsh, gbuffers_weather.vsh
		In world1: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.vsh
		In world7: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_armor_glint.fsh, gbuffers_block.fsh, gbuffers_hand_water.vsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.vsh

Old Clouds:
	Internal name: OLD_CLOUDS
	Description: Makes fancy clouds more square-shaped
	Default Value: false
	Recommended values: true false
	Found in:
		In world-1: gbuffers_block.fsh
		In world0: composite1.fsh/vsh, gbuffers_block.fsh
		In world1: gbuffers_block.fsh
		In world7: gbuffers_block.fsh

Overworld (in darkness):
	Internal name: EYE_ADJUST_OVERWORLD_DARK
	Description: Brightness multiplier for the whole screen when standing in darkness in the overworld
	Default Value: 3.0
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world0: composite1.vsh

Overworld (in light):
	Internal name: EYE_ADJUST_OVERWORLD_LIGHT
	Description: Brightness multiplier for the whole screen when standing in bright light in the overworld
	Default Value: 1.5
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world0: composite1.vsh

Overworld Fog:
	Internal name: FOG_ENABLED_OVERWORLD
	Description: Enables fog in the overworld. It is recommended to have this enabled if you also have infinite oceans enabled!
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_water.fsh

Overworld Horizon Height:
	Internal name: OVERWORLD_HORIZON_HEIGHT
	Description: How far above the horizon the fog color will be applied
	Default Value: 0.2
	Recommended values: 0.001 ~ 1.0
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

Overworld Horizon Saturation:
	Internal name: OVERWORLD_FOG_SATURATION_BOOST
	Description: Makes the horizon blue-er
	Default Value: 1.25
	Recommended values: 0.00 ~ 2.50
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

Overworld Sky Saturation:
	Internal name: OVERWORLD_SKY_SATURATION_BOOST
	Description: Makes the sky blue-er
	Default Value: 1.50
	Recommended values: 0.00 ~ 2.50
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

Rain Blur:
	Internal name: RAIN_BLUR
	Description: Blurs the world while raining
	Default Value: 10
	Recommended values: 0 ~ 25
	Found in:
		In world0: composite1.fsh

Rain Desaturation:
	Internal name: DESATURATE_RAIN
	Description: Amount to desaturate the world when raining
	Default Value: 0.50
	Recommended values: 0.00 ~ 1.00
	Found in:
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Rainbow Enchantments:
	Internal name: RAINBOW_ENCHANTMENTS
	Description: If enabled, the enchantment glint will be rainbow instead of the default purple color
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_armor_glint.fsh/vsh
		In world0: gbuffers_armor_glint.fsh/vsh
		In world1: gbuffers_armor_glint.fsh/vsh
		In world7: gbuffers_armor_glint.fsh/vsh

rainbowPosition (localization missing):
	Description: 1.0 will be on top of the sun, 0.0 will be on top of the moon.
	Default Value: 0.25
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

rainbowThinness (localization missing):
	Description: Positive numbers will make red be on the inside and blue on the outside.
	Default Value: -24.0
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

Randomize Humidity:
	Internal name: GRASS_PATCHES
	Description: Makes grass less uniform by making patches of it dryer or lusher. Does not affect leaves.
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Randomize Lava Brightness:
	Internal name: LAVA_PATCHES
	Description: Randomizes lava brightness, similar to grass patches
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: gbuffers_terrain.fsh/vsh
		In world0: gbuffers_terrain.fsh/vsh
		In world1: gbuffers_terrain.fsh/vsh
		In world7: gbuffers_terrain.fsh/vsh

Refract Amount:
	Internal name: REFRACT_AMOUNT
	Description: Multiplier for the amount of refraction applied to water
	Default Value: 1.00
	Recommended values: 0.10 ~ 5.00
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Refraction:
	Internal name: WATER_REFRACT
	Description: Distorts things behind water
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Remove X/Z offset:
	Internal name: REMOVE_XZ_OFFSET
	Description: Removes random X/Z offset from tallgrass/flowers/etc...
	Default Value: false
	Recommended values: true false
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Remove Y offset:
	Internal name: REMOVE_Y_OFFSET
	Description: Removes random Y offset from tallgrass/flowers/etc...
	Default Value: false
	Recommended values: true false
	Found in:
		In world-1: gbuffers_terrain.vsh
		In world0: gbuffers_terrain.vsh
		In world1: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Sea Level:
	Internal name: SEA_LEVEL
	Description: Sea level for infinite oceans. Change this if you use custom worldgen.
	Default Value: 63
	Recommended values: 0 ~ 256
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh

Shade Strength:
	Internal name: SHADE_STRENGTH
	Description: How dark surfaces that are facing away from the sun are
	Default Value: 0.35
	Recommended values: 0.00 ~ 0.50
	Found in:
		In world0: gbuffers_block.vsh, gbuffers_entities.vsh, gbuffers_hand.vsh, gbuffers_hand_water.vsh, gbuffers_terrain.vsh, gbuffers_water.vsh

Sky Reflections:
	Internal name: REFLECT
	Description: Reflects the sun/sky onto reflective surfaces. Does not add reflections of terrain!
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite1.fsh
		In world7: composite1.fsh

skylightColorAtNight (localization missing):
	Description: If hardcore darkness is enabled, this will be 0 instead.
	Default Value: vec3(0.05, 0.1, 0.15)
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh

skylightColorDuringTheDay (localization missing):
	Default Value: vec3(1.0,  1.0, 1.0)
	Found in:
		In world0: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh

skylightVibrantColor (localization missing):
	Default Value: vec3(1.1, 1.4, 1.2)
	Found in:
		In world7: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

skylightVibrantColorAtNight (localization missing):
	Default Value: vec3(1.0, 1.1, 1.4)
	Found in:
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

skylightVibrantColorDuringTheDay (localization missing):
	Default Value: vec3(1.4, 1.2, 1.1)
	Found in:
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

skylightVibrantColorWhenRaining (localization missing):
	Description: Overrides both day and night.
	Default Value: vec3(1.0, 1.0, 1.0)
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Soul Fire Integration:
	Internal name: SOUL_FIRE_INTEGRATION
	Description: When enabled, block light will be tinted blue in soul sand valleys
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Soul Lava:
	Internal name: SOUL_LAVA
	Description: When enabled, lava and magma blocks will be blue tinted in soul sand valleys
	Default Value: true
	Recommended values: true false
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_terrain.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh

starRotation (localization missing):
	Default Value: mat2(
cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994),
sin(sunPathRotation * 0.01745329251994),  cos(sunPathRotation * 0.01745329251994)
)
	Found in:
		In world0: gbuffers_skybasic.fsh

Sun Path Rotation:
	Internal name: sunPathRotation
	Description: Angle that the sun/moon rotate at
	Default Value: 30.0
	Recommended values: -45.0 ~ 45.0
	Found in:
		In world0: gbuffers_skybasic.fsh/vsh

Sun Position Fix:
	Internal name: SUN_POSITION_FIX
	Description: Enable this if the horizon "splits" at sunset when rapidly rotating your camera.
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_skybasic.fsh/vsh

sunGlowColor (localization missing):
	Description: Mixed with sky color based on distance from sun
	Default Value: vec3(1.0,   1.0,   1.0 )
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite1.fsh, gbuffers_skybasic.fsh

sunReflectionBrightness (localization missing):
	Description: this value should be slightly bigger than 0.
	Default Value: 0.025
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite1.fsh

sunReflectionColorAtSunset (localization missing):
	Default Value: vec3(1.0, 0.5,   0.25)
	Found in:
		In world0: composite1.fsh

sunReflectionColorDuringTheDay (localization missing):
	Default Value: vec3(1.0, 0.875, 0.75)
	Found in:
		In world0: composite1.fsh

sunReflectionInverseBrightness (localization missing):
	Description: this value should be slightly bigger than 1.
	Default Value: 1.001
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite1.fsh

sunRotationData (localization missing):
	Description: Used for manually calculating the sun's position, since the sunPosition uniform is inaccurate in the skybasic stage. radians() is inlined as * PI / 180.0 because radians() doesn't count as a constant function on some drivers.
	Default Value: vec2(cos(sunPathRotation * 0.01745329251994), -sin(sunPathRotation * 0.01745329251994))
	Recommended values: (no recommended values provided)
	Found in:
		In world0: gbuffers_skybasic.vsh

sunsetColorForOtherThings (localization missing):
	Default Value: sunsetColorForSky + vec3(0.2, 0.2, 0.2)
	Found in:
		In world0: composite.vsh, composite1.vsh, gbuffers_hand_water.vsh, gbuffers_water.vsh

sunsetColorForSky (localization missing):
	Description: Subtract 6.0 from this to get the color of the horizon at sunset.
	Default Value: vec3(7.2, 6.7, 6.2)
	Recommended values: (no recommended values provided)
	Found in:
		In world0: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh, gbuffers_clouds.fsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_skybasic.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh

Twilight Forest (in darkness):
	Internal name: EYE_ADJUST_TF_DARK
	Description: Brightness multiplier for the whole screen when standing in darkness in the twilight forest
	Default Value: 3.0
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world7: composite1.vsh

Twilight Forest (in light):
	Internal name: EYE_ADJUST_TF_LIGHT
	Description: Brightness multiplier for the whole screen when standing in bright light in the twilight forest
	Default Value: 1.5
	Recommended values: 0.5 ~ 4.0
	Found in:
		In world7: composite1.vsh

Twilight Forest Auroras:
	Internal name: TF_AURORAS
	Description: Adds auroras to the sky in the twilight forest
	Default Value: true
	Recommended values: true false
	Found in:
		In world7: composite.fsh

Twilight Forest Fog:
	Internal name: FOG_ENABLED_TF
	Description: Enables fog in the twilight forest
	Default Value: true
	Recommended values: true false
	Found in:
		In world7: composite.fsh, composite1.fsh, gbuffers_water.fsh

Twilight Forest Horizon Height:
	Internal name: TF_HORIZON_HEIGHT
	Description: How far above the horizon the fog color will be applied
	Default Value: 0.05
	Recommended values: 0.001 ~ 1.0
	Found in:
		In world7: composite.fsh, composite1.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh

Twilight Forest Sky Fix:
	Internal name: TF_SKY_FIX
	Description: Enable this if the sky looks wrong in the twilight forest
	Default Value: true
	Recommended values: true false
	Found in:
		In world7: composite.fsh

Underwater Blur:
	Internal name: UNDERWATER_BLUR
	Description: Blurs the world while underwater
	Default Value: 8
	Recommended values: 0 ~ 25
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Underwater Fog:
	Internal name: UNDERWATER_FOG
	Description: Applies fog to water
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite.fsh, composite1.fsh
		In world7: composite.fsh, composite1.fsh

Vanilla Light Colors:
	Internal name: VANILLA_LIGHTMAP
	Description: Uses vanilla light colors instead of custom ones. Requires optifine 1.12.2 HD_U_D1 or later!
	Default Value: false
	Recommended values: true false
	Found in:
		In world-1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world1: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, composite1.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Vibrant Colors:
	Internal name: CROSS_PROCESS
	Description: Opposite of desaturation, makes everything more vibrant and saturated.
	Default Value: false
	Recommended values: true false
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh/vsh, composite1.fsh, composite1.vsh, gbuffers_block.fsh, gbuffers_clouds.fsh, gbuffers_hand_water.fsh, gbuffers_hand_water.vsh, gbuffers_skybasic.fsh, gbuffers_terrain.vsh, gbuffers_water.fsh, gbuffers_water.vsh
		In world1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world7: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

vibrantSaturation (localization missing):
	Description: Higher numbers mean more saturation when vibrant colors are enabled.
	Default Value: 0.1
	Recommended values: (no recommended values provided)
	Found in:
		In world-1: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh
		In world0: composite.fsh, gbuffers_hand_water.fsh, gbuffers_water.fsh

Void Cloud Height:
	Internal name: VOID_CLOUD_HEIGHT
	Description: Y level of void clouds
	Default Value: 128.0
	Recommended values: -64.0 ~ 512.0
	Found in:
		In world1: composite1.fsh/vsh

Void Clouds:
	Internal name: VOID_CLOUDS
	Description: Dark ominous clouds in the end
	Default Value: true
	Recommended values: true false
	Found in:
		In world1: composite1.fsh/vsh

Water Blur:
	Internal name: WATER_BLUR
	Description: Blurs things behind water
	Default Value: 4
	Recommended values: 0 ~ 25
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

Water Wave Strength:
	Internal name: WATER_WAVE_STRENGTH
	Description: Makes overworld oceans move up and down
	Default Value: 50
	Recommended values: 0 ~ 100
	Found in:
		In world0: gbuffers_terrain.vsh, gbuffers_water.vsh
		In world7: gbuffers_terrain.vsh, gbuffers_water.vsh

waterAbsorbColor (localization missing):
	Default Value: vec3(0.2,  0.05, 0.1)
	Found in:
		In world7: composite.fsh, composite1.fsh

waterAbsorbColorWhenRaining (localization missing):
	Default Value: vec3(0.125, 0.0625, 0.25)
	Found in:
		In world0: composite.fsh, composite1.fsh

waterAbsorbColorWhenSunny (localization missing):
	Default Value: vec3(0.2,   0.05,   0.1)
	Found in:
		In world0: composite.fsh, composite1.fsh

waterNoiseScale (localization missing):
	Default Value: 0.0625
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

waterNoiseSpeed (localization missing):
	Default Value: 2.0
	Found in:
		In world-1: composite1.fsh
		In world0: composite1.fsh
		In world1: composite1.fsh
		In world7: composite1.fsh

waterScatterColor (localization missing):
	Default Value: vec3(0.05, 0.4,  0.5)
	Found in:
		In world7: composite.fsh, composite1.fsh

waterScatterColorWhenRaining (localization missing):
	Default Value: vec3(0.09375, 0.1, 0.15)
	Found in:
		In world0: composite.fsh, composite1.fsh

waterScatterColorWhenSunny (localization missing):
	Default Value: vec3(0.05,    0.4, 0.5)
	Found in:
		In world0: composite.fsh, composite1.fsh

Wave Normals:
	Internal name: WATER_NORMALS
	Description: Distorts things reflected by water. Has no effect when reflections are disabled!
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite1.fsh
		In world7: composite1.fsh

Waving Grass:
	Internal name: WAVING_GRASS
	Description: Adds wind effects to grass
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Waving Leaves:
	Internal name: WAVING_LEAVES
	Description: Adds wind effects to leaves
	Default Value: false
	Recommended values: true false
	Found in:
		In world0: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Waving Rain:
	Internal name: WAVING_RAIN
	Description: Makes rain not directly vertical by applying "wind" to it.
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_weather.vsh

Waving Vines:
	Internal name: WAVING_VINES
	Description: Adds wind effects to vines
	Default Value: false
	Recommended values: true false
	Found in:
		In world0: gbuffers_terrain.vsh
		In world7: gbuffers_terrain.vsh

Wet Dirt:
	Internal name: WET_DIRT
	Description: Hydrated hummus. Soggy soil. Drenched dirt. I can't think of a good name for this config option, but it makes dirt darker during rain to simulate being wet.
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: gbuffers_terrain.fsh/vsh

§cR§6a§ei§an§bb§9o§5w§ds§r:
	Internal name: RAINBOWS
	Description: If enabled, rainbows will appear when the weather changes from rainy to clear
	Default Value: true
	Recommended values: true false
	Found in:
		In world0: composite.fsh, composite1.fsh, gbuffers_clouds.fsh, gbuffers_skybasic.fsh, gbuffers_water.fsh