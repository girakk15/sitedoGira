#if COLORED_LIGHTS % 2 == 1
    #extension GL_ARB_shader_image_load_store : require
#endif

#ifndef VOXY_TERRAIN
    uniform float viewWidth;
    uniform float viewHeight;
    uniform float aspectRatio;
    uniform int isEyeInWater;
    uniform float frameTimeCounter;
    uniform float frameTime;
    uniform int frameCounter;
    uniform vec3 fogColor;
    uniform vec3 skyColor;
#ifndef HZP_U_cameraPosition
#define HZP_U_cameraPosition
    uniform vec3 cameraPosition;
#endif
    uniform vec4 entityColor;
    uniform int worldTime;
    uniform float rainStrength;
    uniform float temperature;
    uniform vec3 sunPosition;
    uniform int worldDay;
    uniform int heldBlockLightValue;
    uniform float darknessFactor;
    uniform float darknessLightFactor;
    uniform float blindness;
    uniform ivec2 eyeBrightnessSmooth;
    uniform vec3 previousCameraPosition;
    uniform int entityId;
    uniform float nightVision;
    uniform float sunAngleAtHome;
    uniform float screenBrightness;
    uniform int renderStage;
    uniform float thunderStrength;
    uniform vec4 lightningBoltPosition;
    uniform bool hideGUI;
    uniform float endFlashIntensity;
    uniform vec3 endFlashPosition;
    const float alphaTestRef = 0.1;
    uniform int blockEntityId;
    uniform float centerDepthSmooth;
    uniform ivec2 atlasSize;
    uniform float wetness;
    uniform float sunAngle;
    uniform vec3 relativeEyePosition;
#ifndef HZP_U_cameraPosition
#define HZP_U_cameraPosition
uniform vec3 cameraPosition;
#endif
#ifndef cameraPositionFract
#define cameraPositionFract fract(cameraPosition)
#endif
    uniform vec3 shadowLightPosition;
    uniform int heldItemId;
    uniform int heldItemId2;
    uniform float fogEnd;
    
    uniform sampler2D colortex0;
    uniform sampler2D colortex1;
    uniform sampler2D colortex2;
    uniform sampler2D colortex3;
    uniform sampler2D gaux1;
    uniform sampler2D gaux2;
    const hz_tex3d gaux3 = hz_tex3d(hz_t3id_gaux3);
    uniform sampler2D gaux4;
    uniform sampler2D colortex8;
    uniform sampler2D colortex9;
    #ifdef VOXY
    uniform sampler2D colortex16;
    #endif
    uniform sampler2D depthtex0;
    uniform sampler2D depthtex1;
    const bvec3 noisetex = bvec3(true);
    uniform sampler2DShadow shadowtex0;
    uniform sampler2DShadow shadowtex1;
    uniform sampler2D shadowcolor0;
    const hz_ctex normals = hz_ctex(vec4(0.5, 0.5, 1.0, 1.0));
    const hz_ctex specular = hz_ctex(vec4(0.0));
    uniform sampler2D gtexture;

    uniform mat4 gbufferProjectionInverse;
    uniform mat4 gbufferProjection;
    uniform mat4 gbufferModelView;
    uniform mat4 gbufferModelViewInverse;
    uniform mat4 gbufferPreviousModelView;
    uniform mat4 gbufferPreviousProjection;
    uniform mat4 shadowModelView;
    uniform mat4 shadowModelViewInverse;
    uniform mat4 shadowProjection;
    uniform mat4 shadowProjectionInverse;

    uniform float near;
    uniform float far;

    uniform float timeAngle;
    uniform float nightStrength;
    uniform float dayStrength;
    uniform float sunsetStrength;
    uniform float sunriseStrength;
    uniform vec2 resolution;
    uniform vec2 resolutionInv;
    uniform vec3 slpN;
    uniform vec3 sunPosN;
    uniform vec2 taaJitter;
    uniform float isOutdoorsSmooth;
    uniform float precipitationSmooth;
    uniform float fogAmount;
    uniform float rainbowStrength;
    uniform vec3 slpPlayerN;

    uniform sampler2D vxDepthTexTrans;
    uniform sampler2D vxDepthTexOpaque;
    uniform mat4 vxProjInv;
    uniform mat4 vxProj;
    uniform mat4 vxProjPrev;
    uniform mat4 vxModelView;
    uniform mat4 vxModelViewInv;
    uniform mat4 vxModelViewPrev;
    uniform int vxRenderDistance;

    #if COLORED_LIGHTS % 2 == 1
        const hz_tex3d voxelImgSampler_a = hz_tex3d(hz_t3id_voxelImgSampler_a);
        const hz_tex3d voxelImgSampler_b = hz_tex3d(hz_t3id_voxelImgSampler_b);
    #endif
#endif

#ifdef VOXY
    #define DISTANT_HORIZONS

    #define dhDepthTex0 vxDepthTexTrans
    #define dhDepthTex1 vxDepthTexOpaque

    #define dhProjectionInverse vxProjInv
    #define dhProjection vxProj
    #define dhPreviousProjection vxProjPrev
    
    #define dhRenderDistance (vxRenderDistance*16)
#else
    uniform sampler2D dhDepthTex0;
    uniform sampler2D dhDepthTex1;

    uniform mat4 dhProjectionInverse;
    uniform mat4 dhProjection;
    uniform mat4 dhPreviousProjection;

    uniform int dhRenderDistance;
#endif
const int noiseTextureResolution = 256;

const float PI = 3.1415926535897;
const float TAU = 2 * PI;
const float gr = 1.6180339887498;

#if COLORED_LIGHTS % 2 == 1
    layout(rgba8) uniform restrict image3D voxelImg_a;
    layout(rgba8) uniform restrict image3D voxelImg_b;
#endif