#version 400 compatibility
// horizon-shaderport noise-2d: the game loads no noise texture; built from the pack's image
#ifndef HZ_TEX2N
#define HZ_TEX2N
// noisetex is a bvec3: no other stand-in overloads that type (naga takes two struct types as one)
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// /img/cloud_noise+normal.png 256x256: r smooth (6 cells), g smooth (26 cells), b smooth (15 cells), a flat
float hz_n2_q0(float x) {
    if (x <= 0.226730) return mix(0.105882, 0.294118, clamp((x - 0.130096) / 0.096635, 0.0, 1.0));
    if (x <= 0.268185) return mix(0.294118, 0.349020, clamp((x - 0.226730) / 0.041455, 0.0, 1.0));
    if (x <= 0.307529) return mix(0.349020, 0.380392, clamp((x - 0.268185) / 0.039343, 0.0, 1.0));
    if (x <= 0.342541) return mix(0.380392, 0.403922, clamp((x - 0.307529) / 0.035012, 0.0, 1.0));
    if (x <= 0.378355) return mix(0.403922, 0.427451, clamp((x - 0.342541) / 0.035814, 0.0, 1.0));
    if (x <= 0.412830) return mix(0.427451, 0.450980, clamp((x - 0.378355) / 0.034475, 0.0, 1.0));
    if (x <= 0.446384) return mix(0.450980, 0.470588, clamp((x - 0.412830) / 0.033554, 0.0, 1.0));
    if (x <= 0.481599) return mix(0.470588, 0.490196, clamp((x - 0.446384) / 0.035215, 0.0, 1.0));
    if (x <= 0.518903) return mix(0.490196, 0.513726, clamp((x - 0.481599) / 0.037305, 0.0, 1.0));
    if (x <= 0.559857) return mix(0.513726, 0.533333, clamp((x - 0.518903) / 0.040954, 0.0, 1.0));
    if (x <= 0.605515) return mix(0.533333, 0.556863, clamp((x - 0.559857) / 0.045658, 0.0, 1.0));
    if (x <= 0.658045) return mix(0.556863, 0.584314, clamp((x - 0.605515) / 0.052530, 0.0, 1.0));
    if (x <= 0.720494) return mix(0.584314, 0.615686, clamp((x - 0.658045) / 0.062448, 0.0, 1.0));
    if (x <= 0.773685) return mix(0.615686, 0.650980, clamp((x - 0.720494) / 0.053191, 0.0, 1.0));
    if (x <= 0.826535) return mix(0.650980, 0.694118, clamp((x - 0.773685) / 0.052850, 0.0, 1.0));
    if (x <= 0.967764) return mix(0.694118, 0.909804, clamp((x - 0.826535) / 0.141229, 0.0, 1.0));
    return 0.909804;
}
float hz_n2_q1(float x) {
    if (x <= 0.166411) return mix(0.211765, 0.368627, clamp((x - 0.012469) / 0.153942, 0.0, 1.0));
    if (x <= 0.241939) return mix(0.368627, 0.396078, clamp((x - 0.166411) / 0.075528, 0.0, 1.0));
    if (x <= 0.299831) return mix(0.396078, 0.423529, clamp((x - 0.241939) / 0.057893, 0.0, 1.0));
    if (x <= 0.349766) return mix(0.423529, 0.443137, clamp((x - 0.299831) / 0.049935, 0.0, 1.0));
    if (x <= 0.393750) return mix(0.443137, 0.454902, clamp((x - 0.349766) / 0.043984, 0.0, 1.0));
    if (x <= 0.432948) return mix(0.454902, 0.470588, clamp((x - 0.393750) / 0.039198, 0.0, 1.0));
    if (x <= 0.470397) return mix(0.470588, 0.490196, clamp((x - 0.432948) / 0.037449, 0.0, 1.0));
    if (x <= 0.508357) return mix(0.490196, 0.501961, clamp((x - 0.470397) / 0.037960, 0.0, 1.0));
    if (x <= 0.545722) return mix(0.501961, 0.517647, clamp((x - 0.508357) / 0.037365, 0.0, 1.0));
    if (x <= 0.583479) return mix(0.517647, 0.529412, clamp((x - 0.545722) / 0.037757, 0.0, 1.0));
    if (x <= 0.619942) return mix(0.529412, 0.549020, clamp((x - 0.583479) / 0.036464, 0.0, 1.0));
    if (x <= 0.659246) return mix(0.549020, 0.556863, clamp((x - 0.619942) / 0.039303, 0.0, 1.0));
    if (x <= 0.705650) return mix(0.556863, 0.576471, clamp((x - 0.659246) / 0.046404, 0.0, 1.0));
    if (x <= 0.758527) return mix(0.576471, 0.603922, clamp((x - 0.705650) / 0.052877, 0.0, 1.0));
    if (x <= 0.828070) return mix(0.603922, 0.631373, clamp((x - 0.758527) / 0.069542, 0.0, 1.0));
    if (x <= 0.994382) return mix(0.631373, 0.780392, clamp((x - 0.828070) / 0.166312, 0.0, 1.0));
    return 0.780392;
}
float hz_n2_q2(float x) {
    if (x <= 0.188995) return mix(0.196078, 0.368627, clamp((x - 0.010593) / 0.178403, 0.0, 1.0));
    if (x <= 0.261153) return mix(0.368627, 0.403922, clamp((x - 0.188995) / 0.072157, 0.0, 1.0));
    if (x <= 0.320492) return mix(0.403922, 0.423529, clamp((x - 0.261153) / 0.059339, 0.0, 1.0));
    if (x <= 0.368548) return mix(0.423529, 0.443137, clamp((x - 0.320492) / 0.048056, 0.0, 1.0));
    if (x <= 0.410607) return mix(0.443137, 0.462745, clamp((x - 0.368548) / 0.042059, 0.0, 1.0));
    if (x <= 0.451035) return mix(0.462745, 0.470588, clamp((x - 0.410607) / 0.040427, 0.0, 1.0));
    if (x <= 0.489134) return mix(0.470588, 0.490196, clamp((x - 0.451035) / 0.038099, 0.0, 1.0));
    if (x <= 0.528138) return mix(0.490196, 0.501961, clamp((x - 0.489134) / 0.039004, 0.0, 1.0));
    if (x <= 0.564267) return mix(0.501961, 0.517647, clamp((x - 0.528138) / 0.036129, 0.0, 1.0));
    if (x <= 0.599666) return mix(0.517647, 0.529412, clamp((x - 0.564267) / 0.035399, 0.0, 1.0));
    if (x <= 0.634856) return mix(0.529412, 0.537255, clamp((x - 0.599666) / 0.035191, 0.0, 1.0));
    if (x <= 0.671916) return mix(0.537255, 0.556863, clamp((x - 0.634856) / 0.037060, 0.0, 1.0));
    if (x <= 0.720673) return mix(0.556863, 0.576471, clamp((x - 0.671916) / 0.048757, 0.0, 1.0));
    if (x <= 0.771488) return mix(0.576471, 0.596078, clamp((x - 0.720673) / 0.050815, 0.0, 1.0));
    if (x <= 0.838371) return mix(0.596078, 0.623529, clamp((x - 0.771488) / 0.066882, 0.0, 1.0));
    if (x <= 0.993597) return mix(0.623529, 0.784314, clamp((x - 0.838371) / 0.155226, 0.0, 1.0));
    return 0.784314;
}
vec4 hz_n2_img(vec2 p) { return vec4(hz_n2_q0(hz_t3_noise(vec3(p, 0.0), 6.000000, 17.000000)), hz_n2_q1(hz_t3_noise(vec3(p, 0.0), 26.000000, 70.000000)), hz_n2_q2(hz_t3_noise(vec3(p, 0.0), 15.000000, 123.000000)), 1.000000); }
const ivec2 hz_n2_size = ivec2(256, 256);
#ifndef texture
vec4 texture(bvec3 t, vec2 p) { return hz_n2_img(p); }
vec4 texture(bvec3 t, vec2 p, float bias) { return hz_n2_img(p); }
#endif
vec4 textureLod(bvec3 t, vec2 p, float lod) { return hz_n2_img(p); }
vec4 textureGrad(bvec3 t, vec2 p, vec2 dx, vec2 dy) { return hz_n2_img(p); }
vec4 texelFetch(bvec3 t, ivec2 c, int lod) { return hz_n2_img((vec2(c) + 0.5) / vec2(hz_n2_size)); }
ivec2 textureSize(bvec3 t, int lod) { return max(hz_n2_size >> lod, ivec2(1)); }
#endif
// horizon-shaderport stand-in-3d: 3D textures the game cannot bind, built from the pack's data
#ifndef HZ_TEX3D
#define HZ_TEX3D
struct hz_tex3d { int id; };
const int hz_t3id_gaux3 = 0;
const int hz_t3id_voxelImgSampler_a = -1;
const int hz_t3id_voxelImgSampler_b = -1;
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// /img/worley_perlin.bin: noise, 5 cell(s) per tile by channel (the file's detail: 25% in a shrunk copy)
vec4 hz_t3_0(vec3 p) { return vec4(clamp(0.323233 + (hz_t3_noise(p, 5.000000, 13.000000) - 0.495103) * 1.339455, 0.000000, 1.000000), 0.0, 0.0, 1.0); }
const ivec3 hz_t3_size_0 = ivec3(64, 64, 64);
vec4 hz_t3(int id, vec3 p) {
    if (id == 0) return hz_t3_0(p);
    return vec4(0.0, 0.0, 0.0, 1.0);
}
ivec3 hz_t3_size(int id) {
    if (id == 0) return hz_t3_size_0;
    return ivec3(1);
}
#ifndef texture
vec4 texture(hz_tex3d t, vec3 p) { return hz_t3(t.id, p); }
vec4 texture(hz_tex3d t, vec3 p, float bias) { return hz_t3(t.id, p); }
#endif
vec4 textureLod(hz_tex3d t, vec3 p, float lod) { return hz_t3(t.id, p); }
vec4 texelFetch(hz_tex3d t, ivec3 c, int lod) { return hz_t3(t.id, (vec3(c) + 0.5) / vec3(hz_t3_size(t.id))); }
ivec3 textureSize(hz_tex3d t, int lod) { return max(hz_t3_size(t.id) >> lod, ivec3(1)); }
#endif
// horizon-shaderport pbr-defaults: no PBR atlases in Horizon; the values Iris gives without them
#ifndef HZ_CTEX
#define HZ_CTEX
struct hz_ctex { vec4 v; };
#ifndef texture
vec4 texture(hz_ctex t, vec2 p) { return t.v; }
vec4 texture(hz_ctex t, vec2 p, float bias) { return t.v; }
#endif
vec4 textureLod(hz_ctex t, vec2 p, float lod) { return t.v; }
vec4 textureGrad(hz_ctex t, vec2 p, vec2 dx, vec2 dy) { return t.v; }
vec4 texelFetch(hz_ctex t, ivec2 p, int lod) { return t.v; }
ivec2 textureSize(hz_ctex t, int lod) { return ivec2(1); }
#endif
#define DIMENSION_NETHER

#include "/program/dh_water.fsh"
