#version 400 compatibility
#define DIMENSION_END

#include "/program/composite1.vsh"