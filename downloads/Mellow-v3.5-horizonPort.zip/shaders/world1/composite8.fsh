#version 400 compatibility
// horizon-shaderport noise-2d: the game loads no noise texture; built from the pack's image
#ifndef HZ_TEX2N
#define HZ_TEX2N
// noisetex is a bvec3: no other stand-in overloads that type (naga takes two struct types as one)
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
vec4 hz_n2_img(vec2 p) { vec2 c = mod(floor(p * 256.0), 256.0); return vec4(hz_t3_hash(vec3(c, 17.0)), hz_t3_hash(vec3(c, 70.0)), hz_t3_hash(vec3(c, 123.0)), 1.0); }
const ivec2 hz_n2_size = ivec2(256);
#ifndef texture
vec4 texture(bvec3 t, vec2 p) { return hz_n2_img(p); }
vec4 texture(bvec3 t, vec2 p, float bias) { return hz_n2_img(p); }
#endif
vec4 textureLod(bvec3 t, vec2 p, float lod) { return hz_n2_img(p); }
vec4 textureGrad(bvec3 t, vec2 p, vec2 dx, vec2 dy) { return hz_n2_img(p); }
vec4 texelFetch(bvec3 t, ivec2 c, int lod) { return hz_n2_img((vec2(c) + 0.5) / vec2(hz_n2_size)); }
ivec2 textureSize(bvec3 t, int lod) { return max(hz_n2_size >> lod, ivec2(1)); }
#endif
#define DIMENSION_END

#include "/program/composite8.fsh"