#version 400 compatibility
#define main hz_keep_vmain
#define DIMENSION_OVERWORLD

#include "/program/composite6.vsh"

#undef main
// horizon-shaderport post-keep: the pass covers the whole screen; the pack's quad is found from
// three corners and every output is computed at the matching point of it.
flat out vec2 hz_keep_p0;
flat out vec2 hz_keep_e1;
flat out vec2 hz_keep_e2;
vec2 hz_keep_ndc(vec2 v) {
    gl_Vertex = vec4(v, 0.0, 1.0);
    gl_MultiTexCoord0 = gl_Vertex;
    hz_keep_vmain();
    return gl_Position.xy / gl_Position.w;
}
void main() {
    vec4 hz_corner = gl_Vertex;
    vec2 p0 = hz_keep_ndc(vec2(0.0));
    vec2 e1 = hz_keep_ndc(vec2(1.0, 0.0)) - p0;
    vec2 e2 = hz_keep_ndc(vec2(0.0, 1.0)) - p0;
    vec2 c = hz_corner.xy * 2.0 - 1.0;
    mat2 m = mat2(e1, e2);
    vec2 v = abs(determinant(m)) > 1e-8 ? inverse(m) * (c - p0) : hz_corner.xy;
    gl_Vertex = vec4(v, hz_corner.zw);
    gl_MultiTexCoord0 = gl_Vertex;
    hz_keep_vmain();
    gl_Position = vec4(c, gl_Position.z / gl_Position.w, 1.0);
    hz_keep_p0 = p0;
    hz_keep_e1 = e1;
    hz_keep_e2 = e2;
}
