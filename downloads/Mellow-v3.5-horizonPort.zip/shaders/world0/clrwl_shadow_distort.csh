#version 400 compatibility
#define DIMENSION_OVERWORLD

#include "/program/clrwl_shadow_distort.csh"