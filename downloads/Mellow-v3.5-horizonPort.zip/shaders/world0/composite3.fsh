#version 400 compatibility
#define main hz_keep_main
#define DIMENSION_OVERWORLD

#include "/program/composite3.fsh"
#undef main
// horizon-shaderport post-keep
flat in vec2 hz_keep_p0;
flat in vec2 hz_keep_e1;
flat in vec2 hz_keep_e2;
void main() {
    ivec2 hz_px = ivec2(gl_FragCoord.xy);
    vec2 hz_ndc = gl_FragCoord.xy / vec2(textureSize(colortex1, 0)) * 2.0 - 1.0;
    vec2 hz_v = inverse(mat2(hz_keep_e1, hz_keep_e2)) * (hz_ndc - hz_keep_p0);
    if (any(lessThan(hz_v, vec2(0.0))) || any(greaterThan(hz_v, vec2(1.0)))) {
        Color = texelFetch(colortex1, hz_px, 0);
        return;
    }
    hz_keep_main();
}
