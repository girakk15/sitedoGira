// horizon-shaderport stand-in-3d: 3D textures the game cannot bind, built from the pack's data
#ifndef HZ_TEX3D
#define HZ_TEX3D
struct hz_tex3d { int id; };
const int hz_t3id_gaux3 = 0;
const int hz_t3id_voxelImgSampler_a = -1;
const int hz_t3id_voxelImgSampler_b = -1;
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// /img/worley_perlin.bin: noise, 5 cell(s) per tile by channel (the file's detail: 25% in a shrunk copy)
vec4 hz_t3_0(vec3 p) { return vec4(clamp(0.323233 + (hz_t3_noise(p, 5.000000, 13.000000) - 0.495103) * 1.339455, 0.000000, 1.000000), 0.0, 0.0, 1.0); }
const ivec3 hz_t3_size_0 = ivec3(64, 64, 64);
vec4 hz_t3(int id, vec3 p) {
    if (id == 0) return hz_t3_0(p);
    return vec4(0.0, 0.0, 0.0, 1.0);
}
ivec3 hz_t3_size(int id) {
    if (id == 0) return hz_t3_size_0;
    return ivec3(1);
}
#ifndef texture
vec4 texture(hz_tex3d t, vec3 p) { return hz_t3(t.id, p); }
vec4 texture(hz_tex3d t, vec3 p, float bias) { return hz_t3(t.id, p); }
#endif
vec4 textureLod(hz_tex3d t, vec3 p, float lod) { return hz_t3(t.id, p); }
vec4 texelFetch(hz_tex3d t, ivec3 c, int lod) { return hz_t3(t.id, (vec3(c) + 0.5) / vec3(hz_t3_size(t.id))); }
ivec3 textureSize(hz_tex3d t, int lod) { return max(hz_t3_size(t.id) >> lod, ivec3(1)); }
#endif
out vec2 LightmapCoords;
out vec2 texcoord;
out vec4 glcolor;
flat out float material;
out vec3 ViewPos;
#ifdef HZ_NFIX_Normal
out vec3 hz_nfix_in_Normal; vec3 Normal;
#else
out vec3 Normal;
#endif
out vec4 Tangent;
flat out vec2 AtlasScale;
flat out vec2 AtlasOffset;

#include "/global/lighting/light_colors.vsh"
#include "/global/atmosphere/sky.glsl"
#include "/global/pbr.glsl"
#include "/global/lighting/shadows.glsl"
#include "/global/atmosphere/clouds.glsl"
#include "/global/water.glsl"
#include "/global/lighting/lighting.glsl"

attribute vec4 mc_Entity;
attribute vec2 mc_midTexCoord;
attribute vec4 at_tangent;

void init_generic() {
    init_colors();

    gl_Position = ftransform();
    texcoord = get_texcoord(gl_TextureMatrix[0], gl_MultiTexCoord0);
    LightmapCoords = get_lightmap(gl_TextureMatrix[1], gl_MultiTexCoord1);
    #ifdef GBUFFERS_BLOCK
        material = blockEntityId != 65535 ? blockEntityId : 0;
    #else
        material = mc_Entity.x;
    #endif    
    ViewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    glcolor = gl_Color;

    Normal = normalize(gl_NormalMatrix * gl_Normal);
    #ifdef CHECK_GRASS_NORMALS
        if (material >= 10003 && material <= 10006) {
            Normal = gbufferModelView[1].xyz;
            // Make grass darker at the bottom. It looks better this way
            if (gl_MultiTexCoord0.t > mc_midTexCoord.t && (material == 10004 || material == 10005)) Normal *= 0.5;
        }
    #endif

    Tangent.xyz = gl_NormalMatrix * normalize(at_tangent.xyz + vec3(1e-9,0,0)); // Prevents nans when at_tangent is 0 (which can happen with some mods)
    Tangent.w = at_tangent.w;

    LightmapCoords = tweak_lightmap_vertex(LightmapCoords, SUN_AMBIENT, SUN_DIRECT, normalize(ViewPos), Normal, view_player(ViewPos, false));

    vec2 midcoord = mc_midTexCoord.xy;
    AtlasScale = abs(texcoord - midcoord) * 2;
    AtlasOffset = min(texcoord, 2 * midcoord - texcoord);
}
