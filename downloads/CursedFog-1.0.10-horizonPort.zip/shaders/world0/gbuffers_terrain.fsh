#version 130
// horizon-shaderport pbr-defaults: no PBR atlases in Horizon; the values Iris gives without them
#ifndef HZ_CTEX
#define HZ_CTEX
struct hz_ctex { vec4 v; };
#ifndef texture
vec4 texture(hz_ctex t, vec2 p) { return t.v; }
vec4 texture(hz_ctex t, vec2 p, float bias) { return t.v; }
#endif
vec4 textureLod(hz_ctex t, vec2 p, float lod) { return t.v; }
vec4 textureGrad(hz_ctex t, vec2 p, vec2 dx, vec2 dy) { return t.v; }
vec4 texelFetch(hz_ctex t, ivec2 p, int lod) { return t.v; }
ivec2 textureSize(hz_ctex t, int lod) { return ivec2(1); }
#endif
#define main hz_pack_main
#define HZ_NFIX_Normal
#define HZ_NFIX_tangent
#define HZ_NFIX_viewSpaceGeoNormal

#include "/settings.glsl"

in vec3 foliageColor;

uniform sampler2D texture;
uniform float rainStrength;

uniform int worldTime;

float state;

in vec2 TexCoords;
in vec2 LightmapCoords;
#ifdef HZ_NFIX_tangent
in vec3 hz_nfix_in_tangent; vec3 tangent;
#else
in vec3 tangent;
#endif
#ifdef HZ_NFIX_viewSpaceGeoNormal
in vec3 hz_nfix_in_viewSpaceGeoNormal; vec3 viewSpaceGeoNormal;
#else
in vec3 viewSpaceGeoNormal;
#endif
in vec3 viewSpacePosition;
#ifdef HZ_NFIX_Normal
in vec3 hz_nfix_in_Normal; vec3 Normal;
#else
in vec3 Normal;
#endif

const hz_ctex normals = hz_ctex(vec4(0.5, 0.5, 1.0, 1.0));
const hz_ctex specular = hz_ctex(vec4(0.0));
uniform int isEyeInWater;
uniform vec3 cameraPosition;
uniform vec3 shadowLightPosition;

uniform mat4 gbufferModelViewInverse;

mat3 tbnNormalTangent(vec3 normal, vec3 tangent) {
    vec3 bitangent = normalize(cross(tangent,normal));
    return mat3(tangent, bitangent, normal);
}

float smoothTransition(float time) {
    if (time >= 0.0f && time <= 1000.0f) {
        return time / 1000.0f; // Transition from 0 to 1
    } else if (time > 1000.0f && time < 12000.0f) {
        return 1.0f; // Fully enabled
    } else if (time >= 12000.0f && time <= 13000.0f) {
        return 1.0f - (time - 12000.0f) / 1000.0f; // Transition from 1 to 0
    } else {
        return 0.0f; // Fully disabled
    }
}

void main(){
    vec4 albedo = texture2D(texture, TexCoords);
	albedo.rgb *= foliageColor;
	
	state = smoothTransition(worldTime);
	
	vec3 redTone = vec3(1.0, 0.2, 0.2);  // Red-tinted color
	#if RED_FILTER == 1
	albedo.rgb = mix(albedo.rgb, redTone, 0.25 * state * (1 - rainStrength));  // Adjust the blending factor for intensity
	#endif
	
    float lightBrightness = 0.0f;
	
	vec2 LC = LightmapCoords;
	if(isEyeInWater == 1) {
		LC += vec2(0.2f);
	}
	else if (isEyeInWater == 2) {
		albedo.rgb = vec3(0.6, 0.1, 0.0);
	}
	
	vec3 shadowLightDir = normalize(mat3(gbufferModelViewInverse) * shadowLightPosition);
	#if PBR == 1
	vec3 viewSpaceInitialTangent = tangent.xyz;
	vec3 viewSpaceTangent = normalize(viewSpaceInitialTangent - dot(viewSpaceInitialTangent, viewSpaceGeoNormal) * viewSpaceGeoNormal);
	
	vec4 normalData = texture2D(normals,TexCoords) * 2.0 - 1.0;
	vec3 normalNormalSpace = vec3(normalData.xy,sqrt(1.0 - dot(normalData.xy, normalData.xy)));
	mat3 TBN = tbnNormalTangent(viewSpaceGeoNormal, viewSpaceTangent);
	vec3 normalViewSpace = TBN * normalNormalSpace;
	vec3 normalWorldSpace = mat3(gbufferModelViewInverse) * normalViewSpace;

	
	float perceptualSmoothness = texture2D(specular, TexCoords).r;
	float roughness = pow(1.0 - perceptualSmoothness, 2.0);
	float smoothness = 1 - roughness;
	
	vec3 fragFeetPlayerSpace = (gbufferModelViewInverse * vec4(viewSpacePosition, 1.0)).xyz;
	vec3 fragWorldSpace = fragFeetPlayerSpace + cameraPosition;
	
	vec3 reflectionDir = reflect(-shadowLightDir, normalWorldSpace);
	vec3 viewDir = normalize(cameraPosition - fragWorldSpace);
	
	float diffuseLight = roughness * clamp(dot(shadowLightDir, normalWorldSpace), 0.0f, 1.0f);
	float shininess = (1 + (smoothness) * 50);
	float specularLight = clamp(smoothness * pow(dot(reflectionDir, viewDir), shininess), 0.0, 1.0) * 2;
	lightBrightness = diffuseLight + specularLight;
	#else
	lightBrightness = clamp(dot(shadowLightDir, Normal), 0.0f, 1.0f);
	#endif

    /* DRAWBUFFERS:02 */
    gl_FragData[0] = albedo;
    gl_FragData[1] = vec4(LC, lightBrightness, 1.0f);
}

// face-normals (horizon-shaderport)
#undef main
in vec3 hz_nfix_vpos;
mat3 hz_nfix_rw;
mat3 hz_nfix_rv;
void hz_nfix_frame() {
    vec3 hz_n = cross(dFdx(hz_nfix_vpos), dFdy(hz_nfix_vpos));
    hz_n = dot(hz_n, hz_n) > 1e-24 ? normalize(hz_n) : vec3(0.0, 0.0, 1.0);
    if (dot(hz_n, hz_nfix_vpos) > 0.0) hz_n = -hz_n;
    mat3 hz_v = mat3(gl_ModelViewMatrix);
    vec3 hz_w = transpose(hz_v) * hz_n;
    vec3 hz_a = abs(hz_w);
    float hz_m = max(hz_a.x, max(hz_a.y, hz_a.z));
    if (hz_m > 0.97) hz_w = step(vec3(hz_m), hz_a) * sign(hz_w);
    hz_w = normalize(hz_w);
    vec3 hz_t = abs(hz_w.y) > 0.9 ? vec3(1.0, 0.0, 0.0) : normalize(cross(vec3(0.0, 1.0, 0.0), hz_w));
    hz_nfix_rw = mat3(hz_t, hz_w, cross(hz_t, hz_w));
    hz_nfix_rv = hz_v * hz_nfix_rw * transpose(hz_v);
}
void main() {
    hz_nfix_frame();
    Normal = hz_nfix_rw * hz_nfix_in_Normal;
    tangent = hz_nfix_rv * hz_nfix_in_tangent;
    viewSpaceGeoNormal = hz_nfix_rv * hz_nfix_in_viewSpaceGeoNormal;
    hz_pack_main();
}
