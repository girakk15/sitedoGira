#version 330 compatibility
#define main hz_pack_main
#define HZ_NFIX_normal

uniform mat4 shadowModelView;
uniform mat4 shadowProjection;
uniform float frameTimeCounter;

in vec3 vaPosition;
in vec3 vaNormal;
in vec2 mc_Entity;

out vec2 lmcoord;
out vec2 texcoord;
out vec4 glcolor;
out vec3 vertexPosition;
out vec3 worldPosition;
out float depth;
#ifdef HZ_NFIX_normal
out vec3 hz_nfix_in_normal; vec3 normal;
#else
out vec3 normal;
#endif
out float blockId;

#include "/world1/lib_world1.glsl"
#include "waves.glsl"

void main() {
	texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
	lmcoord  = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
	glcolor = gl_Color;
	vertexPosition = gl_Vertex.xyz;
	vec4 viewPos = gl_ModelViewMatrix * gl_Vertex;
	worldPosition = ViewPosToWorldPos(viewPos.xyz);
	//depth = (gl_ProjectionMatrix * gl_ModelViewMatrix * gl_Vertex).z;
	depth = length(viewPos.xyz);
	normal = gl_Normal;
	blockId = mc_Entity.x;

	// Vertical displacement of vertices
	bool water = abs(blockId - 10060) < 0.1;
	if(water)
	{
		float wave = getWaves(worldPosition.xz, 10);
		worldPosition.y += wave*waves_amplitude;
	}

	gl_Position = gl_ProjectionMatrix * vec4(WorldPosToViewPos(worldPosition), 1.0);
}

// face-normals (horizon-shaderport)
#undef main
out vec3 hz_nfix_vpos;
void main() {
    hz_pack_main();
    hz_nfix_in_normal = normal;
    hz_nfix_vpos = (gl_ModelViewMatrix * gl_Vertex).xyz;
}
