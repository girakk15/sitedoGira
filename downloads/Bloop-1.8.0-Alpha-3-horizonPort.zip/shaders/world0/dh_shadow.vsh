#version 140 compatibility
// horizon-shaderport noise-2d: the game loads no noise texture; built from the pack's image
#ifndef HZ_TEX2N
#define HZ_TEX2N
// noisetex is a bvec3: no other stand-in overloads that type (naga takes two struct types as one)
#ifndef HZ_T3_NOISE
#define HZ_T3_NOISE
float hz_t3_hash(vec3 p) { p = fract(p * 0.1031); p += dot(p, p.zyx + 31.32); return fract((p.x + p.y) * p.z); }
float hz_t3_noise(vec3 p, float n, float seed) {
    vec3 q = p * n; vec3 i = floor(q); vec3 f = q - i; f = f * f * (3.0 - 2.0 * f);
    vec3 a = i - n * floor(i / n) + seed; vec3 b = (i + 1.0) - n * floor((i + 1.0) / n) + seed;
    return mix(mix(mix(hz_t3_hash(vec3(a.x, a.y, a.z)), hz_t3_hash(vec3(b.x, a.y, a.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, a.z)), hz_t3_hash(vec3(b.x, b.y, a.z)), f.x), f.y),
               mix(mix(hz_t3_hash(vec3(a.x, a.y, b.z)), hz_t3_hash(vec3(b.x, a.y, b.z)), f.x),
                   mix(hz_t3_hash(vec3(a.x, b.y, b.z)), hz_t3_hash(vec3(b.x, b.y, b.z)), f.x), f.y), f.z);
}
#endif
// texture/newNoise.png 512x512: r white, g white, b smooth (10 cells), a white
float hz_n2_q2(float x) {
    if (x <= 0.186704) return mix(0.000000, 0.000000, clamp((x - 0.009446) / 0.177258, 0.0, 1.0));
    if (x <= 0.253420) return mix(0.000000, 0.003922, clamp((x - 0.186704) / 0.066717, 0.0, 1.0));
    if (x <= 0.320482) return mix(0.003922, 0.007843, clamp((x - 0.253420) / 0.067062, 0.0, 1.0));
    if (x <= 0.373235) return mix(0.007843, 0.015686, clamp((x - 0.320482) / 0.052753, 0.0, 1.0));
    if (x <= 0.414067) return mix(0.015686, 0.019608, clamp((x - 0.373235) / 0.040831, 0.0, 1.0));
    if (x <= 0.458346) return mix(0.019608, 0.027451, clamp((x - 0.414067) / 0.044280, 0.0, 1.0));
    if (x <= 0.501470) return mix(0.027451, 0.035294, clamp((x - 0.458346) / 0.043124, 0.0, 1.0));
    if (x <= 0.538610) return mix(0.035294, 0.043137, clamp((x - 0.501470) / 0.037140, 0.0, 1.0));
    if (x <= 0.577219) return mix(0.043137, 0.050980, clamp((x - 0.538610) / 0.038609, 0.0, 1.0));
    if (x <= 0.611504) return mix(0.050980, 0.062745, clamp((x - 0.577219) / 0.034285, 0.0, 1.0));
    if (x <= 0.648050) return mix(0.062745, 0.074510, clamp((x - 0.611504) / 0.036547, 0.0, 1.0));
    if (x <= 0.686711) return mix(0.074510, 0.090196, clamp((x - 0.648050) / 0.038661, 0.0, 1.0));
    if (x <= 0.731327) return mix(0.090196, 0.105882, clamp((x - 0.686711) / 0.044615, 0.0, 1.0));
    if (x <= 0.775776) return mix(0.105882, 0.129412, clamp((x - 0.731327) / 0.044450, 0.0, 1.0));
    if (x <= 0.839974) return mix(0.129412, 0.164706, clamp((x - 0.775776) / 0.064197, 0.0, 1.0));
    if (x <= 0.973191) return mix(0.164706, 0.372549, clamp((x - 0.839974) / 0.133218, 0.0, 1.0));
    return 0.372549;
}
vec4 hz_n2_img(vec2 p) { return vec4(clamp(0.310334 + (hz_t3_hash(vec3(mod(floor(p * vec2(512.0, 512.0)), vec2(512.0, 512.0)), 17.000000)) - 0.5) * 1.016516, 0.000000, 1.000000), clamp(0.308811 + (hz_t3_hash(vec3(mod(floor(p * vec2(512.0, 512.0)), vec2(512.0, 512.0)), 70.000000)) - 0.5) * 1.018131, 0.000000, 1.000000), hz_n2_q2(hz_t3_noise(vec3(p, 0.0), 10.000000, 123.000000)), clamp(0.500970 + (hz_t3_hash(vec3(mod(floor(p * vec2(512.0, 512.0)), vec2(512.0, 512.0)), 176.000000)) - 0.5) * 1.006599, 0.000000, 1.000000)); }
const ivec2 hz_n2_size = ivec2(512, 512);
#ifndef texture
vec4 texture(bvec3 t, vec2 p) { return hz_n2_img(p); }
vec4 texture(bvec3 t, vec2 p, float bias) { return hz_n2_img(p); }
#endif
vec4 textureLod(bvec3 t, vec2 p, float lod) { return hz_n2_img(p); }
vec4 textureGrad(bvec3 t, vec2 p, vec2 dx, vec2 dy) { return hz_n2_img(p); }
vec4 texelFetch(bvec3 t, ivec2 c, int lod) { return hz_n2_img((vec2(c) + 0.5) / vec2(hz_n2_size)); }
ivec2 textureSize(bvec3 t, int lod) { return max(hz_n2_size >> lod, ivec2(1)); }
#endif
// horizon-shaderport stand-in-3d: 3D textures the game cannot bind, built from the pack's data
#ifndef HZ_TEX3D
#define HZ_TEX3D
struct hz_tex3d { int id; };
const int hz_t3id_colortex15 = -1;
const int hz_t3id_physics_foam = -1;
const int hz_t3id_texLpv1 = -1;
const int hz_t3id_texLpv2 = -1;
vec4 hz_t3(int id, vec3 p) {
    return vec4(0.0, 0.0, 0.0, 1.0);
}
ivec3 hz_t3_size(int id) {
    return ivec3(1);
}
#ifndef texture
vec4 texture(hz_tex3d t, vec3 p) { return hz_t3(t.id, p); }
vec4 texture(hz_tex3d t, vec3 p, float bias) { return hz_t3(t.id, p); }
#endif
vec4 textureLod(hz_tex3d t, vec3 p, float lod) { return hz_t3(t.id, p); }
vec4 texelFetch(hz_tex3d t, ivec3 c, int lod) { return hz_t3(t.id, (vec3(c) + 0.5) / vec3(hz_t3_size(t.id))); }
ivec3 textureSize(hz_tex3d t, int lod) { return max(hz_t3_size(t.id) >> lod, ivec3(1)); }
#endif
// horizon-shaderport pbr-defaults: no PBR atlases in Horizon; the values Iris gives without them
#ifndef HZ_CTEX
#define HZ_CTEX
struct hz_ctex { vec4 v; };
#ifndef texture
vec4 texture(hz_ctex t, vec2 p) { return t.v; }
vec4 texture(hz_ctex t, vec2 p, float bias) { return t.v; }
#endif
vec4 textureLod(hz_ctex t, vec2 p, float lod) { return t.v; }
vec4 textureGrad(hz_ctex t, vec2 p, vec2 dx, vec2 dy) { return t.v; }
vec4 texelFetch(hz_ctex t, ivec2 p, int lod) { return t.v; }
ivec2 textureSize(hz_ctex t, int lod) { return ivec2(1); }
#endif
#include "/includes/main.glsl"
#define OVERWORLD





varying vec4 color;
varying vec3 viewVector;

varying vec4 lmtexcoord;


vec3 mul3(const in mat4 matrix, const in vec3 vector)
{
    return mat3(matrix) * vector + matrix[3].xyz;
}

bool intersectCone(float coneHalfAngle, vec3 coneTip, vec3 coneAxis, vec3 rayOrig, vec3 rayDir, float maxZ)
{
    vec3 co = rayOrig - coneTip;
    float prod = dot(normalize(co), coneAxis);
    if (prod <= -coneHalfAngle)
        return true; // In view frustrum

    float a = dot(rayDir, coneAxis) * dot(rayDir, coneAxis) - coneHalfAngle * coneHalfAngle;
    float b = 2. * (dot(rayDir, coneAxis) * dot(co, coneAxis) - dot(rayDir, co) * coneHalfAngle * coneHalfAngle);
    float c = dot(co, coneAxis) * dot(co, coneAxis) - dot(co, co) * coneHalfAngle * coneHalfAngle;

    float det = b * b - 4. * a * c;
    if (det < 0.)
        return false; // No intersection with either forward cone and backward cone

    det = sqrt(det);
    float t2 = (-b + det) / (2. * a);
    if (t2 <= 0.0 || t2 >= maxZ)
        return false; // Idk why it works

    return true;
}

void main()
{

    // vec3 position2 = mat3(gl_ModelViewMatrix) * vec3(gl_Vertex) + gl_ModelViewMatrix[3].xyz;

    // vec2 light = vec2(gl_MultiTexCoord1.xy * recip);

    // if (intersectCone(cosFov, shadowCamera, shadowViewDir, position2, -shadowLightVec, shadowMaxProj) && light.y > 0.001)
    {
        vec3 shadowViewPos = mul3(gl_ModelViewMatrix, gl_Vertex.xyz);
        viewVector = mul3(shadowModelViewInverse, shadowViewPos);

        color = gl_Color;
        vec4 position = gl_ModelViewProjectionMatrix * gl_Vertex;
        position.z *= 0.1666666666666667; // 1/6
        if (dhMaterialId != 1)
        {
            position.z += 0.001;
        }

        vec2 shadowDistortion = calcShadowDistortion(position.xyz);
        position.xy = shadowDistortion;

        lmtexcoord.xyzw = vec4(gl_MultiTexCoord0.xy, gl_MultiTexCoord1.xy * 1);

        gl_Position = position;
    }
    // else
    {
        //    color = vec4(0.0);

        //     gl_Position.xyzw = vec4(0.0, 0.0, 1e30, 0.0); // Degenerates the triangle
    }
}
